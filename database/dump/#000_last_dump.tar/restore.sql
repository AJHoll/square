--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.11
-- Dumped by pg_dump version 12.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE square;
--
-- Name: square; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE square WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Russian_Russia.1251@icu' LC_CTYPE = 'Russian_Russia.1251';


\connect square

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: square; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA square;


--
-- Name: dblink; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS dblink WITH SCHEMA public;


--
-- Name: EXTENSION dblink; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION dblink IS 'connect to other PostgreSQL databases from within a database';


--
-- Name: t_boolean; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_boolean AS boolean;


--
-- Name: t_booleanarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_booleanarray AS boolean[];


--
-- Name: t_caption; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_caption AS character varying(254);


--
-- Name: t_captionarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_captionarray AS character varying(254)[];


--
-- Name: t_clob; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_clob AS text;


--
-- Name: t_code; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_code AS character varying(254);


--
-- Name: t_codearray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_codearray AS character varying(254)[];


--
-- Name: t_date; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_date AS date;


--
-- Name: t_datearray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_datearray AS date[];


--
-- Name: t_datetime; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_datetime AS timestamp without time zone;


--
-- Name: t_datetimearray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_datetimearray AS timestamp without time zone[];


--
-- Name: t_description; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_description AS character varying(4000);


--
-- Name: t_float; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_float AS numeric;


--
-- Name: t_html; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_html AS text;


--
-- Name: t_id; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_id AS numeric(15,0);


--
-- Name: t_idarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_idarray AS numeric(15,0)[];


--
-- Name: t_integer; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_integer AS integer;


--
-- Name: t_integerarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_integerarray AS integer[];


--
-- Name: t_json; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_json AS jsonb;


--
-- Name: t_longstring; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_longstring AS character varying(4000);


--
-- Name: t_longstringarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_longstringarray AS character varying(4000)[];


--
-- Name: t_money; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_money AS numeric(15,4);


--
-- Name: t_moneyarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_moneyarray AS numeric(15,4)[];


--
-- Name: t_name; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_name AS character varying(30);


--
-- Name: t_namearray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_namearray AS character varying(30)[];


--
-- Name: t_shortstring; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_shortstring AS character varying(254);


--
-- Name: t_shortstringarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_shortstringarray AS character varying(254)[];


--
-- Name: t_stringarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_stringarray AS text[];


--
-- Name: t_xml; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_xml AS xml;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: adm_group; Type: TABLE; Schema: square; Owner: -
--

CREATE TABLE square.adm_group (
    id public.t_id NOT NULL,
    name public.t_name DEFAULT ''::character varying NOT NULL,
    caption public.t_caption,
    description public.t_description
);


--
-- Name: TABLE adm_group; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON TABLE square.adm_group IS 'Группы доступа';


--
-- Name: COLUMN adm_group.id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_group.id IS 'ID';


--
-- Name: COLUMN adm_group.name; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_group.name IS 'Системное имя группы';


--
-- Name: COLUMN adm_group.caption; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_group.caption IS 'Наименование группы';


--
-- Name: COLUMN adm_group.description; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_group.description IS 'Описание';


--
-- Name: adm_group_in_user; Type: TABLE; Schema: square; Owner: -
--

CREATE TABLE square.adm_group_in_user (
    id public.t_id NOT NULL,
    user_id public.t_id NOT NULL,
    group_id public.t_id NOT NULL
);


--
-- Name: TABLE adm_group_in_user; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON TABLE square.adm_group_in_user IS 'Группы пользователя';


--
-- Name: COLUMN adm_group_in_user.id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_group_in_user.id IS 'ID';


--
-- Name: COLUMN adm_group_in_user.user_id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_group_in_user.user_id IS 'ID Пользователя';


--
-- Name: COLUMN adm_group_in_user.group_id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_group_in_user.group_id IS 'ID Группы';


--
-- Name: adm_role; Type: TABLE; Schema: square; Owner: -
--

CREATE TABLE square.adm_role (
    id public.t_id NOT NULL,
    name public.t_name DEFAULT ''::character varying NOT NULL,
    caption public.t_caption,
    description public.t_description
);


--
-- Name: TABLE adm_role; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON TABLE square.adm_role IS 'Роли доступа';


--
-- Name: COLUMN adm_role.id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_role.id IS 'ID';


--
-- Name: COLUMN adm_role.name; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_role.name IS 'Системное имя роли';


--
-- Name: COLUMN adm_role.caption; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_role.caption IS 'Наименование роли';


--
-- Name: COLUMN adm_role.description; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_role.description IS 'Описание';


--
-- Name: adm_role_in_group; Type: TABLE; Schema: square; Owner: -
--

CREATE TABLE square.adm_role_in_group (
    id public.t_id NOT NULL,
    group_id public.t_id NOT NULL,
    role_id public.t_id NOT NULL
);


--
-- Name: TABLE adm_role_in_group; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON TABLE square.adm_role_in_group IS 'Роли в группах';


--
-- Name: COLUMN adm_role_in_group.id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_role_in_group.id IS 'ID';


--
-- Name: COLUMN adm_role_in_group.group_id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_role_in_group.group_id IS 'ID Группы';


--
-- Name: COLUMN adm_role_in_group.role_id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_role_in_group.role_id IS 'ID Роли';


--
-- Name: adm_user; Type: TABLE; Schema: square; Owner: -
--

CREATE TABLE square.adm_user (
    id public.t_id NOT NULL,
    name public.t_name DEFAULT ''::character varying NOT NULL,
    caption public.t_caption,
    hash public.t_shortstring,
    person_id public.t_id
);


--
-- Name: TABLE adm_user; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON TABLE square.adm_user IS 'Пользователи площадки';


--
-- Name: COLUMN adm_user.id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_user.id IS 'ID';


--
-- Name: COLUMN adm_user.name; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_user.name IS 'Системное имя пользователя (email)';


--
-- Name: COLUMN adm_user.caption; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_user.caption IS 'Наименование (ФИО/Название организации)';


--
-- Name: COLUMN adm_user.hash; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_user.hash IS 'Хэщ пароля';


--
-- Name: COLUMN adm_user.person_id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_user.person_id IS 'ID Физ. лица';


--
-- Name: seq_adm_group; Type: SEQUENCE; Schema: square; Owner: -
--

CREATE SEQUENCE square.seq_adm_group
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_adm_group_in_user; Type: SEQUENCE; Schema: square; Owner: -
--

CREATE SEQUENCE square.seq_adm_group_in_user
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_adm_role; Type: SEQUENCE; Schema: square; Owner: -
--

CREATE SEQUENCE square.seq_adm_role
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_adm_role_in_group; Type: SEQUENCE; Schema: square; Owner: -
--

CREATE SEQUENCE square.seq_adm_role_in_group
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_adm_user; Type: SEQUENCE; Schema: square; Owner: -
--

CREATE SEQUENCE square.seq_adm_user
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Data for Name: adm_group; Type: TABLE DATA; Schema: square; Owner: -
--

COPY square.adm_group (id, name, caption, description) FROM stdin;
\.
COPY square.adm_group (id, name, caption, description) FROM '$$PATH$$/3057.dat';

--
-- Data for Name: adm_group_in_user; Type: TABLE DATA; Schema: square; Owner: -
--

COPY square.adm_group_in_user (id, user_id, group_id) FROM stdin;
\.
COPY square.adm_group_in_user (id, user_id, group_id) FROM '$$PATH$$/3060.dat';

--
-- Data for Name: adm_role; Type: TABLE DATA; Schema: square; Owner: -
--

COPY square.adm_role (id, name, caption, description) FROM stdin;
\.
COPY square.adm_role (id, name, caption, description) FROM '$$PATH$$/3058.dat';

--
-- Data for Name: adm_role_in_group; Type: TABLE DATA; Schema: square; Owner: -
--

COPY square.adm_role_in_group (id, group_id, role_id) FROM stdin;
\.
COPY square.adm_role_in_group (id, group_id, role_id) FROM '$$PATH$$/3059.dat';

--
-- Data for Name: adm_user; Type: TABLE DATA; Schema: square; Owner: -
--

COPY square.adm_user (id, name, caption, hash, person_id) FROM stdin;
\.
COPY square.adm_user (id, name, caption, hash, person_id) FROM '$$PATH$$/3056.dat';

--
-- Name: seq_adm_group; Type: SEQUENCE SET; Schema: square; Owner: -
--

SELECT pg_catalog.setval('square.seq_adm_group', 1, true);


--
-- Name: seq_adm_group_in_user; Type: SEQUENCE SET; Schema: square; Owner: -
--

SELECT pg_catalog.setval('square.seq_adm_group_in_user', 1, true);


--
-- Name: seq_adm_role; Type: SEQUENCE SET; Schema: square; Owner: -
--

SELECT pg_catalog.setval('square.seq_adm_role', 1, true);


--
-- Name: seq_adm_role_in_group; Type: SEQUENCE SET; Schema: square; Owner: -
--

SELECT pg_catalog.setval('square.seq_adm_role_in_group', 1, true);


--
-- Name: seq_adm_user; Type: SEQUENCE SET; Schema: square; Owner: -
--

SELECT pg_catalog.setval('square.seq_adm_user', 1, true);


--
-- Name: udx_adm_group_in_user_user_id; Type: INDEX; Schema: square; Owner: -
--

CREATE UNIQUE INDEX udx_adm_group_in_user_user_id ON square.adm_group_in_user USING btree (user_id, group_id);


--
-- Name: udx_adm_role_in_group_group_role_id; Type: INDEX; Schema: square; Owner: -
--

CREATE UNIQUE INDEX udx_adm_role_in_group_group_role_id ON square.adm_role_in_group USING btree (group_id, role_id);


--
-- Name: adm_group pk_adm_group; Type: CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.adm_group
    ADD CONSTRAINT pk_adm_group PRIMARY KEY (id);


--
-- Name: adm_group_in_user pk_adm_group_in_user; Type: CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.adm_group_in_user
    ADD CONSTRAINT pk_adm_group_in_user PRIMARY KEY (id);


--
-- Name: adm_role pk_adm_role; Type: CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.adm_role
    ADD CONSTRAINT pk_adm_role PRIMARY KEY (id);


--
-- Name: adm_role_in_group pk_adm_role_in_group; Type: CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.adm_role_in_group
    ADD CONSTRAINT pk_adm_role_in_group PRIMARY KEY (id);


--
-- Name: adm_user pk_adm_user; Type: CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.adm_user
    ADD CONSTRAINT pk_adm_user PRIMARY KEY (id);


--
-- Name: idx_adm_user_person_id; Type: INDEX; Schema: square; Owner: -
--

CREATE INDEX idx_adm_user_person_id ON square.adm_user USING btree (person_id);


--
-- Name: udx_adm_group_name; Type: INDEX; Schema: square; Owner: -
--

CREATE UNIQUE INDEX udx_adm_group_name ON square.adm_group USING btree (name);


--
-- Name: udx_adm_role_name; Type: INDEX; Schema: square; Owner: -
--

CREATE UNIQUE INDEX udx_adm_role_name ON square.adm_role USING btree (name);


--
-- Name: udx_adm_user_name; Type: INDEX; Schema: square; Owner: -
--

CREATE UNIQUE INDEX udx_adm_user_name ON square.adm_user USING btree (name);


--
-- Name: adm_group_in_user fk_adm_group_in_user_group_id; Type: FK CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.adm_group_in_user
    ADD CONSTRAINT fk_adm_group_in_user_group_id FOREIGN KEY (group_id) REFERENCES square.adm_group(id) ON DELETE CASCADE;


--
-- Name: adm_group_in_user fk_adm_group_in_user_user_id; Type: FK CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.adm_group_in_user
    ADD CONSTRAINT fk_adm_group_in_user_user_id FOREIGN KEY (user_id) REFERENCES square.adm_user(id) ON DELETE CASCADE;


--
-- Name: adm_role_in_group fk_adm_role_in_group_group; Type: FK CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.adm_role_in_group
    ADD CONSTRAINT fk_adm_role_in_group_group FOREIGN KEY (group_id) REFERENCES square.adm_group(id) ON DELETE CASCADE;


--
-- Name: adm_role_in_group fk_adm_role_in_group_role; Type: FK CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.adm_role_in_group
    ADD CONSTRAINT fk_adm_role_in_group_role FOREIGN KEY (role_id) REFERENCES square.adm_role(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

