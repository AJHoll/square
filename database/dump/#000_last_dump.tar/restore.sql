--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.11
-- Dumped by pg_dump version 12.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE square;
--
-- Name: square; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE square WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Russian_Russia.1251@icu' LC_CTYPE = 'Russian_Russia.1251';


\connect square

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: adm_privelegy; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA adm_privelegy;


--
-- Name: adm_role; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA adm_role;


--
-- Name: adm_user; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA adm_user;


--
-- Name: uni_api; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA uni_api;


--
-- Name: uni_component; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA uni_component;


--
-- Name: uni_const; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA uni_const;


--
-- Name: uni_error; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA uni_error;


--
-- Name: uni_generator; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA uni_generator;


--
-- Name: dblink; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS dblink WITH SCHEMA public;


--
-- Name: EXTENSION dblink; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION dblink IS 'connect to other PostgreSQL databases from within a database';


--
-- Name: t_boolean; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_boolean AS boolean;


--
-- Name: t_booleanarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_booleanarray AS boolean[];


--
-- Name: t_caption; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_caption AS character varying(254);


--
-- Name: t_captionarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_captionarray AS character varying(254)[];


--
-- Name: t_clob; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_clob AS text;


--
-- Name: t_code; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_code AS character varying(254);


--
-- Name: t_codearray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_codearray AS character varying(254)[];


--
-- Name: t_date; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_date AS date;


--
-- Name: t_datearray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_datearray AS date[];


--
-- Name: t_datetime; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_datetime AS timestamp without time zone;


--
-- Name: t_datetimearray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_datetimearray AS timestamp without time zone[];


--
-- Name: t_description; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_description AS character varying(4000);


--
-- Name: t_float; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_float AS numeric;


--
-- Name: t_html; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_html AS text;


--
-- Name: t_id; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_id AS numeric(15,0);


--
-- Name: t_idarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_idarray AS numeric(15,0)[];


--
-- Name: t_integer; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_integer AS integer;


--
-- Name: t_integerarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_integerarray AS integer[];


--
-- Name: t_json; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_json AS jsonb;


--
-- Name: t_longstring; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_longstring AS character varying(4000);


--
-- Name: t_longstringarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_longstringarray AS character varying(4000)[];


--
-- Name: t_money; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_money AS numeric(15,4);


--
-- Name: t_moneyarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_moneyarray AS numeric(15,4)[];


--
-- Name: t_name; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_name AS character varying(30);


--
-- Name: t_namearray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_namearray AS character varying(30)[];


--
-- Name: t_shortstring; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_shortstring AS character varying(254);


--
-- Name: t_shortstringarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_shortstringarray AS character varying(254)[];


--
-- Name: t_stringarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_stringarray AS text[];


--
-- Name: t_xml; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_xml AS xml;


--
-- Name: privelegy__after_edit(public.t_id); Type: FUNCTION; Schema: adm_privelegy; Owner: -
--

CREATE FUNCTION adm_privelegy.privelegy__after_edit(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_privelegy.privelegy__after_edit"
        title="Функция after_edit таблицы adm_privelegy.privelegy"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
begin
  perform adm_privelegy.privelegy__validate(idp_self);
end; $$;


--
-- Name: privelegy__delete_record(public.t_id); Type: FUNCTION; Schema: adm_privelegy; Owner: -
--

CREATE FUNCTION adm_privelegy.privelegy__delete_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_privelegy.privelegy__delete_record"
        title="Функция delete_record таблицы adm_privelegy.privelegy"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
begin
 delete from adm_privelegy.privelegy where id = idp_self;
end; $$;


--
-- Name: privelegy__find_by_name(public.t_name); Type: FUNCTION; Schema: adm_privelegy; Owner: -
--

CREATE FUNCTION adm_privelegy.privelegy__find_by_name(sp_name public.t_name) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_privelegy.privelegy__find_by_name"
        title="Функция find_by_name таблицы adm_privelegy.privelegy"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
declare
  nv_count t_integer := 0;
  idv_self t_id;
begin
  select count(*) into nv_count from adm_privelegy.privelegy t where t.s_name = sp_name;
  if nv_count > 1 then
    return 0;
  end if;
  select t.id into idv_self from adm_privelegy.privelegy t where t.s_name = sp_name;
  return idv_self;
end;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: privelegy; Type: TABLE; Schema: adm_privelegy; Owner: -
--

CREATE TABLE adm_privelegy.privelegy (
    id public.t_id NOT NULL,
    s_name public.t_name NOT NULL,
    s_caption public.t_caption,
    d_begin public.t_date NOT NULL,
    d_end public.t_date
);


--
-- Name: TABLE privelegy; Type: COMMENT; Schema: adm_privelegy; Owner: -
--

COMMENT ON TABLE adm_privelegy.privelegy IS 'Привелегии';


--
-- Name: COLUMN privelegy.id; Type: COMMENT; Schema: adm_privelegy; Owner: -
--

COMMENT ON COLUMN adm_privelegy.privelegy.id IS 'Код';


--
-- Name: COLUMN privelegy.s_name; Type: COMMENT; Schema: adm_privelegy; Owner: -
--

COMMENT ON COLUMN adm_privelegy.privelegy.s_name IS 'Системное имя';


--
-- Name: COLUMN privelegy.s_caption; Type: COMMENT; Schema: adm_privelegy; Owner: -
--

COMMENT ON COLUMN adm_privelegy.privelegy.s_caption IS 'Наименование';


--
-- Name: COLUMN privelegy.d_begin; Type: COMMENT; Schema: adm_privelegy; Owner: -
--

COMMENT ON COLUMN adm_privelegy.privelegy.d_begin IS 'Дата с';


--
-- Name: COLUMN privelegy.d_end; Type: COMMENT; Schema: adm_privelegy; Owner: -
--

COMMENT ON COLUMN adm_privelegy.privelegy.d_end IS 'Дата по';


--
-- Name: privelegy__get_row(public.t_id); Type: FUNCTION; Schema: adm_privelegy; Owner: -
--

CREATE FUNCTION adm_privelegy.privelegy__get_row(idp_self public.t_id) RETURNS adm_privelegy.privelegy
    LANGUAGE sql
    AS $$
/*<meta object="adm_privelegy.privelegy__get_row"
        title="Функция get_row таблицы adm_privelegy.privelegy"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
  select t.* from adm_privelegy.privelegy t where t.id = idp_self;
$$;


--
-- Name: privelegy__insert_record(public.t_name, public.t_date); Type: FUNCTION; Schema: adm_privelegy; Owner: -
--

CREATE FUNCTION adm_privelegy.privelegy__insert_record(sp_name public.t_name, dp_begin public.t_date) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_privelegy.privelegy__insert_record"
        title="Функция insert_record таблицы adm_privelegy.privelegy"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
declare
 rv_row adm_privelegy.privelegy%rowtype;
begin
 rv_row.id := uni_api.get_table_id('adm_privelegy','privelegy');
 rv_row.s_name := sp_name;
 rv_row.d_begin := dp_begin;

 insert into adm_privelegy.privelegy(id, s_name, d_begin)
 values(rv_row.id, rv_row.s_name, rv_row.d_begin);

 return rv_row.id;

end; $$;


--
-- Name: privelegy__lock_record(public.t_id); Type: FUNCTION; Schema: adm_privelegy; Owner: -
--

CREATE FUNCTION adm_privelegy.privelegy__lock_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_privelegy.privelegy__lock_record"
        title="Функция lock_record таблицы adm_privelegy.privelegy"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
declare
 bv_is_ok t_boolean;
 sv_component_name t_name = 'UNI';
 sv_error_name t_name = 'ENoLockedRow';
begin
 select true into bv_is_ok from adm_privelegy.privelegy where id = idp_self for update nowait;
 exception when lock_not_available then
   perform uni_error.generate(sv_component_name, sv_error_name, idp_self::t_shortstring);
end; $$;


--
-- Name: privelegy__set_begin(public.t_id, public.t_date, public.t_boolean); Type: FUNCTION; Schema: adm_privelegy; Owner: -
--

CREATE FUNCTION adm_privelegy.privelegy__set_begin(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_privelegy.privelegy__set_begin"
        title="Функция setter для колонки "d_begin" таблицы adm_privelegy.privelegy"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'adm_privelegy';
  sv_table_name t_name = 'privelegy';
  sv_column_name t_name = 'd_begin';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: privelegy__set_caption(public.t_id, public.t_caption, public.t_boolean); Type: FUNCTION; Schema: adm_privelegy; Owner: -
--

CREATE FUNCTION adm_privelegy.privelegy__set_caption(idp_self public.t_id, p_value public.t_caption, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_privelegy.privelegy__set_caption"
        title="Функция setter для колонки "s_caption" таблицы adm_privelegy.privelegy"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'adm_privelegy';
  sv_table_name t_name = 'privelegy';
  sv_column_name t_name = 's_caption';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: privelegy__set_end(public.t_id, public.t_date, public.t_boolean); Type: FUNCTION; Schema: adm_privelegy; Owner: -
--

CREATE FUNCTION adm_privelegy.privelegy__set_end(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_privelegy.privelegy__set_end"
        title="Функция setter для колонки "d_end" таблицы adm_privelegy.privelegy"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'adm_privelegy';
  sv_table_name t_name = 'privelegy';
  sv_column_name t_name = 'd_end';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: privelegy__set_name(public.t_id, public.t_name, public.t_boolean); Type: FUNCTION; Schema: adm_privelegy; Owner: -
--

CREATE FUNCTION adm_privelegy.privelegy__set_name(idp_self public.t_id, p_value public.t_name, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_privelegy.privelegy__set_name"
        title="Функция setter для колонки "s_name" таблицы adm_privelegy.privelegy"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'adm_privelegy';
  sv_table_name t_name = 'privelegy';
  sv_column_name t_name = 's_name';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: privelegy__validate(public.t_id); Type: FUNCTION; Schema: adm_privelegy; Owner: -
--

CREATE FUNCTION adm_privelegy.privelegy__validate(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_privelegy.privelegy__validate"
        title="Функция validate таблицы adm_privelegy.privelegy"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
begin
 null;
end; $$;


--
-- Name: role_privs__after_edit(public.t_id); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.role_privs__after_edit(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_role.role_privs__after_edit"
        title="Функция after_edit таблицы adm_role.role_privs"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
begin
  perform adm_role.role_privs__validate(idp_self);
end; $$;


--
-- Name: role_privs__delete_record(public.t_id); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.role_privs__delete_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_role.role_privs__delete_record"
        title="Функция delete_record таблицы adm_role.role_privs"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
begin
 delete from adm_role.role_privs where id = idp_self;
end; $$;


--
-- Name: role_privs; Type: TABLE; Schema: adm_role; Owner: -
--

CREATE TABLE adm_role.role_privs (
    id public.t_id NOT NULL,
    id_role public.t_id NOT NULL,
    id_privelegy public.t_id NOT NULL,
    d_begin public.t_date NOT NULL,
    d_end public.t_date
);


--
-- Name: TABLE role_privs; Type: COMMENT; Schema: adm_role; Owner: -
--

COMMENT ON TABLE adm_role.role_privs IS 'Привелегии ролей';


--
-- Name: COLUMN role_privs.id; Type: COMMENT; Schema: adm_role; Owner: -
--

COMMENT ON COLUMN adm_role.role_privs.id IS 'Код';


--
-- Name: COLUMN role_privs.id_role; Type: COMMENT; Schema: adm_role; Owner: -
--

COMMENT ON COLUMN adm_role.role_privs.id_role IS 'Код роли';


--
-- Name: COLUMN role_privs.id_privelegy; Type: COMMENT; Schema: adm_role; Owner: -
--

COMMENT ON COLUMN adm_role.role_privs.id_privelegy IS 'Код привелегии';


--
-- Name: COLUMN role_privs.d_begin; Type: COMMENT; Schema: adm_role; Owner: -
--

COMMENT ON COLUMN adm_role.role_privs.d_begin IS 'Дата с';


--
-- Name: COLUMN role_privs.d_end; Type: COMMENT; Schema: adm_role; Owner: -
--

COMMENT ON COLUMN adm_role.role_privs.d_end IS 'Дата по';


--
-- Name: role_privs__get_row(public.t_id); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.role_privs__get_row(idp_self public.t_id) RETURNS adm_role.role_privs
    LANGUAGE sql
    AS $$
/*<meta object="adm_role.role_privs__get_row"
        title="Функция get_row таблицы adm_role.role_privs"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
  select t.* from adm_role.role_privs t where t.id = idp_self;
$$;


--
-- Name: role_privs__insert_record(public.t_id, public.t_id, public.t_date); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.role_privs__insert_record(idp_role public.t_id, idp_privelegy public.t_id, dp_begin public.t_date) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_role.role_privs__insert_record"
        title="Функция insert_record таблицы adm_role.role_privs"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
declare
 rv_row adm_role.role_privs%rowtype;
begin
 rv_row.id := uni_api.get_table_id('adm_role','role_privs');
 rv_row.id_role := idp_role;
 rv_row.id_privelegy := idp_privelegy;
 rv_row.d_begin := dp_begin;

 insert into adm_role.role_privs(id, id_role, id_privelegy, d_begin)
 values(rv_row.id, rv_row.id_role, rv_row.id_privelegy, rv_row.d_begin);

 return rv_row.id;

end; $$;


--
-- Name: role_privs__lock_record(public.t_id); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.role_privs__lock_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_role.role_privs__lock_record"
        title="Функция lock_record таблицы adm_role.role_privs"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
declare
 bv_is_ok t_boolean;
 sv_component_name t_name = 'UNI';
 sv_error_name t_name = 'ENoLockedRow';
begin
 select true into bv_is_ok from adm_role.role_privs where id = idp_self for update nowait;
 exception when lock_not_available then
   perform uni_error.generate(sv_component_name, sv_error_name, idp_self::t_shortstring);
end; $$;


--
-- Name: role_privs__set_begin(public.t_id, public.t_date, public.t_boolean); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.role_privs__set_begin(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_role.role_privs__set_begin"
        title="Функция setter для колонки "d_begin" таблицы adm_role.role_privs"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'adm_role';
  sv_table_name t_name = 'role_privs';
  sv_column_name t_name = 'd_begin';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: role_privs__set_end(public.t_id, public.t_date, public.t_boolean); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.role_privs__set_end(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_role.role_privs__set_end"
        title="Функция setter для колонки "d_end" таблицы adm_role.role_privs"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'adm_role';
  sv_table_name t_name = 'role_privs';
  sv_column_name t_name = 'd_end';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: role_privs__set_privelegy(public.t_id, public.t_id, public.t_boolean); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.role_privs__set_privelegy(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_role.role_privs__set_privelegy"
        title="Функция setter для колонки "id_privelegy" таблицы adm_role.role_privs"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'adm_role';
  sv_table_name t_name = 'role_privs';
  sv_column_name t_name = 'id_privelegy';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: role_privs__set_role(public.t_id, public.t_id, public.t_boolean); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.role_privs__set_role(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_role.role_privs__set_role"
        title="Функция setter для колонки "id_role" таблицы adm_role.role_privs"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'adm_role';
  sv_table_name t_name = 'role_privs';
  sv_column_name t_name = 'id_role';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: role_privs__validate(public.t_id); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.role_privs__validate(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_role.role_privs__validate"
        title="Функция validate таблицы adm_role.role_privs"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
begin
 null;
end; $$;


--
-- Name: role_relation__after_edit(public.t_id); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.role_relation__after_edit(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_role.role_relation__after_edit"
        title="Функция after_edit таблицы adm_role.role_relation"
        author="sys"
        created="21.07.2021"
        version="1.0"
        description="">
</meta>*/
begin
  perform adm_role.role_relation__validate(idp_self);
end; $$;


--
-- Name: role_relation__delete_record(public.t_id); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.role_relation__delete_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_role.role_relation__delete_record"
        title="Функция delete_record таблицы adm_role.role_relation"
        author="sys"
        created="21.07.2021"
        version="1.0"
        description="">
</meta>*/
begin
 delete from adm_role.role_relation where id = idp_self;
end; $$;


--
-- Name: role_relation; Type: TABLE; Schema: adm_role; Owner: -
--

CREATE TABLE adm_role.role_relation (
    id public.t_id NOT NULL,
    id_parent_role public.t_id NOT NULL,
    id_child_role public.t_id NOT NULL,
    d_begin public.t_date DEFAULT (now())::public.t_date NOT NULL,
    d_end public.t_date,
    b_active public.t_boolean DEFAULT true NOT NULL
);


--
-- Name: TABLE role_relation; Type: COMMENT; Schema: adm_role; Owner: -
--

COMMENT ON TABLE adm_role.role_relation IS 'Отношения ролей';


--
-- Name: COLUMN role_relation.id; Type: COMMENT; Schema: adm_role; Owner: -
--

COMMENT ON COLUMN adm_role.role_relation.id IS 'Код';


--
-- Name: COLUMN role_relation.id_parent_role; Type: COMMENT; Schema: adm_role; Owner: -
--

COMMENT ON COLUMN adm_role.role_relation.id_parent_role IS 'Код родительской роли';


--
-- Name: COLUMN role_relation.id_child_role; Type: COMMENT; Schema: adm_role; Owner: -
--

COMMENT ON COLUMN adm_role.role_relation.id_child_role IS 'Код дочерней роли';


--
-- Name: COLUMN role_relation.d_begin; Type: COMMENT; Schema: adm_role; Owner: -
--

COMMENT ON COLUMN adm_role.role_relation.d_begin IS 'Дата начала';


--
-- Name: COLUMN role_relation.d_end; Type: COMMENT; Schema: adm_role; Owner: -
--

COMMENT ON COLUMN adm_role.role_relation.d_end IS 'Дата окончания';


--
-- Name: COLUMN role_relation.b_active; Type: COMMENT; Schema: adm_role; Owner: -
--

COMMENT ON COLUMN adm_role.role_relation.b_active IS 'Активный (Да/Нет)';


--
-- Name: role_relation__get_row(public.t_id); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.role_relation__get_row(idp_self public.t_id) RETURNS adm_role.role_relation
    LANGUAGE sql
    AS $$
/*<meta object="adm_role.role_relation__get_row"
        title="Функция get_row таблицы adm_role.role_relation"
        author="sys"
        created="21.07.2021"
        version="1.0"
        description="">
</meta>*/
  select t.* from adm_role.role_relation t where t.id = idp_self;
$$;


--
-- Name: role_relation__insert_record(public.t_id, public.t_id); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.role_relation__insert_record(idp_parent_role public.t_id, idp_child_role public.t_id) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_role.role_relation__insert_record"
        title="Функция insert_record таблицы adm_role.role_relation"
        author="sys"
        created="21.07.2021"
        version="1.0"
        description="">
</meta>*/
declare
 rv_row adm_role.role_relation%rowtype;
begin
 rv_row.id := uni_api.get_table_id('adm_role','role_relation');
 rv_row.id_parent_role := idp_parent_role;
 rv_row.id_child_role := idp_child_role;

 insert into adm_role.role_relation(id, id_parent_role, id_child_role)
 values(rv_row.id, rv_row.id_parent_role, rv_row.id_child_role);

 return rv_row.id;

end; $$;


--
-- Name: role_relation__lock_record(public.t_id); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.role_relation__lock_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_role.role_relation__lock_record"
        title="Функция lock_record таблицы adm_role.role_relation"
        author="sys"
        created="21.07.2021"
        version="1.0"
        description="">
</meta>*/
declare
 bv_is_ok t_boolean;
 sv_component_name t_name = 'UNI';
 sv_error_name t_name = 'ENoLockedRow';
begin
 select true into bv_is_ok from adm_role.role_relation where id = idp_self for update nowait;
 exception when lock_not_available then
   perform uni_error.generate(sv_component_name, sv_error_name, idp_self::t_shortstring);
end; $$;


--
-- Name: role_relation__set_active(public.t_id, public.t_boolean, public.t_boolean); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.role_relation__set_active(idp_self public.t_id, p_value public.t_boolean, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_role.role_relation__set_active"
        title="Функция setter для колонки "b_active" таблицы adm_role.role_relation"
        author="sys"
        created="21.07.2021"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'adm_role';
  sv_table_name t_name = 'role_relation';
  sv_column_name t_name = 'b_active';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: role_relation__set_begin(public.t_id, public.t_date, public.t_boolean); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.role_relation__set_begin(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_role.role_relation__set_begin"
        title="Функция setter для колонки "d_begin" таблицы adm_role.role_relation"
        author="sys"
        created="21.07.2021"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'adm_role';
  sv_table_name t_name = 'role_relation';
  sv_column_name t_name = 'd_begin';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: role_relation__set_child_role(public.t_id, public.t_id, public.t_boolean); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.role_relation__set_child_role(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_role.role_relation__set_child_role"
        title="Функция setter для колонки "id_child_role" таблицы adm_role.role_relation"
        author="sys"
        created="21.07.2021"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'adm_role';
  sv_table_name t_name = 'role_relation';
  sv_column_name t_name = 'id_child_role';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: role_relation__set_end(public.t_id, public.t_date, public.t_boolean); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.role_relation__set_end(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_role.role_relation__set_end"
        title="Функция setter для колонки "d_end" таблицы adm_role.role_relation"
        author="sys"
        created="21.07.2021"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'adm_role';
  sv_table_name t_name = 'role_relation';
  sv_column_name t_name = 'd_end';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: role_relation__set_parent_role(public.t_id, public.t_id, public.t_boolean); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.role_relation__set_parent_role(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_role.role_relation__set_parent_role"
        title="Функция setter для колонки "id_parent_role" таблицы adm_role.role_relation"
        author="sys"
        created="21.07.2021"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'adm_role';
  sv_table_name t_name = 'role_relation';
  sv_column_name t_name = 'id_parent_role';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: role_relation__validate(public.t_id); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.role_relation__validate(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_role.role_relation__validate"
        title="Функция validate таблицы adm_role.role_relation"
        author="sys"
        created="21.07.2021"
        version="1.0"
        description="">
</meta>*/
begin
 null;
end; $$;


--
-- Name: roles__after_edit(public.t_id); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.roles__after_edit(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
  perform adm_role.roles__validate(idp_self);
end; $$;


--
-- Name: roles__delete_record(public.t_id); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.roles__delete_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
 delete from adm_role.roles where id = idp_self;
end; $$;


--
-- Name: roles__find_by_name(public.t_name); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.roles__find_by_name(sp_name public.t_name) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
declare
  nv_count t_integer := 0;
  idv_self t_id;
begin
  select count(*) into nv_count from adm_role.roles t where t.s_name = sp_name;
  if nv_count > 1 then
    return 0;
  end if;
  select t.id into idv_self from adm_role.roles t where t.s_name = sp_name;
  return idv_self;
end;
$$;


--
-- Name: roles; Type: TABLE; Schema: adm_role; Owner: -
--

CREATE TABLE adm_role.roles (
    id public.t_id NOT NULL,
    s_name public.t_name DEFAULT ('empty'::character varying)::public.t_name NOT NULL,
    s_caption public.t_caption,
    d_begin public.t_date DEFAULT (now())::public.t_date NOT NULL,
    d_end public.t_date,
    b_active public.t_boolean DEFAULT true NOT NULL
);


--
-- Name: TABLE roles; Type: COMMENT; Schema: adm_role; Owner: -
--

COMMENT ON TABLE adm_role.roles IS 'Роли';


--
-- Name: COLUMN roles.id; Type: COMMENT; Schema: adm_role; Owner: -
--

COMMENT ON COLUMN adm_role.roles.id IS 'Код';


--
-- Name: COLUMN roles.s_name; Type: COMMENT; Schema: adm_role; Owner: -
--

COMMENT ON COLUMN adm_role.roles.s_name IS 'Системное имя';


--
-- Name: COLUMN roles.s_caption; Type: COMMENT; Schema: adm_role; Owner: -
--

COMMENT ON COLUMN adm_role.roles.s_caption IS 'Наименование';


--
-- Name: COLUMN roles.d_begin; Type: COMMENT; Schema: adm_role; Owner: -
--

COMMENT ON COLUMN adm_role.roles.d_begin IS 'Дата начала';


--
-- Name: COLUMN roles.d_end; Type: COMMENT; Schema: adm_role; Owner: -
--

COMMENT ON COLUMN adm_role.roles.d_end IS 'Дата окончания';


--
-- Name: COLUMN roles.b_active; Type: COMMENT; Schema: adm_role; Owner: -
--

COMMENT ON COLUMN adm_role.roles.b_active IS 'Активный (Да/Нет)';


--
-- Name: roles__get_row(public.t_id); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.roles__get_row(idp_self public.t_id) RETURNS adm_role.roles
    LANGUAGE sql
    AS $$
  select t.* from adm_role.roles t where t.id = idp_self;
$$;


--
-- Name: roles__insert_record(); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.roles__insert_record() RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
declare
 rv_row adm_role.roles%rowtype;
begin
 rv_row.id := uni_api.get_table_id('adm_role','roles');

 insert into adm_role.roles(id)
 values(rv_row.id);

 return rv_row.id;

end; $$;


--
-- Name: roles__lock_record(public.t_id); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.roles__lock_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
 bv_is_ok t_boolean;
 sv_component_name t_name = 'UNI';
 sv_error_name t_name = 'ENoLockedRow';
begin
 select true into bv_is_ok from adm_role.roles where id = idp_self for update nowait;
 exception when lock_not_available then
   perform uni_error.generate(sv_component_name, sv_error_name, idp_self::t_shortstring);
end; $$;


--
-- Name: roles__set_active(public.t_id, public.t_boolean); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.roles__set_active(idp_self public.t_id, p_value public.t_boolean) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'adm_role';
  sv_table_name t_name = 'roles';
  sv_column_name t_name = 'b_active';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: roles__set_begin(public.t_id, public.t_date); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.roles__set_begin(idp_self public.t_id, p_value public.t_date) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'adm_role';
  sv_table_name t_name = 'roles';
  sv_column_name t_name = 'd_begin';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: roles__set_caption(public.t_id, public.t_caption); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.roles__set_caption(idp_self public.t_id, p_value public.t_caption) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'adm_role';
  sv_table_name t_name = 'roles';
  sv_column_name t_name = 's_caption';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: roles__set_end(public.t_id, public.t_date); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.roles__set_end(idp_self public.t_id, p_value public.t_date) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'adm_role';
  sv_table_name t_name = 'roles';
  sv_column_name t_name = 'd_end';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: roles__set_name(public.t_id, public.t_name); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.roles__set_name(idp_self public.t_id, p_value public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'adm_role';
  sv_table_name t_name = 'roles';
  sv_column_name t_name = 's_name';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: roles__validate(public.t_id); Type: FUNCTION; Schema: adm_role; Owner: -
--

CREATE FUNCTION adm_role.roles__validate(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
 null;
end; $$;


--
-- Name: user_role__after_edit(public.t_id); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_role__after_edit(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
  perform adm_user.user_role__validate(idp_self);
end; $$;


--
-- Name: user_role__delete_record(public.t_id); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_role__delete_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
 delete from adm_user.user_role where id = idp_self;
end; $$;


--
-- Name: user_role; Type: TABLE; Schema: adm_user; Owner: -
--

CREATE TABLE adm_user.user_role (
    id public.t_id NOT NULL,
    id_user public.t_id NOT NULL,
    id_role public.t_id NOT NULL,
    d_begin public.t_date DEFAULT (now())::public.t_date NOT NULL,
    d_end public.t_date,
    b_active public.t_boolean DEFAULT true NOT NULL
);


--
-- Name: TABLE user_role; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON TABLE adm_user.user_role IS 'Роли пользователя';


--
-- Name: COLUMN user_role.id; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON COLUMN adm_user.user_role.id IS 'Код';


--
-- Name: COLUMN user_role.id_user; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON COLUMN adm_user.user_role.id_user IS 'Код пользователя';


--
-- Name: COLUMN user_role.id_role; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON COLUMN adm_user.user_role.id_role IS 'Код роли';


--
-- Name: COLUMN user_role.d_begin; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON COLUMN adm_user.user_role.d_begin IS 'Дата начала';


--
-- Name: COLUMN user_role.d_end; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON COLUMN adm_user.user_role.d_end IS 'Дата окончания';


--
-- Name: COLUMN user_role.b_active; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON COLUMN adm_user.user_role.b_active IS 'Активный (Да/Нет)';


--
-- Name: user_role__get_row(public.t_id); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_role__get_row(idp_self public.t_id) RETURNS adm_user.user_role
    LANGUAGE sql
    AS $$
  select t.* from adm_user.user_role t where t.id = idp_self;
$$;


--
-- Name: user_role__insert_record(public.t_id, public.t_id); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_role__insert_record(idp_user public.t_id, idp_role public.t_id) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
declare
 rv_row adm_user.user_role%rowtype;
begin
 rv_row.id := uni_api.get_table_id('adm_user','user_role');
 rv_row.id_user := idp_user;
 rv_row.id_role := idp_role;

 insert into adm_user.user_role(id, id_user, id_role)
 values(rv_row.id, rv_row.id_user, rv_row.id_role);

 return rv_row.id;

end; $$;


--
-- Name: user_role__lock_record(public.t_id); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_role__lock_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
 bv_is_ok t_boolean;
 sv_component_name t_name = 'UNI';
 sv_error_name t_name = 'ENoLockedRow';
begin
 select true into bv_is_ok from adm_user.user_role where id = idp_self for update nowait;
 exception when lock_not_available then
   perform uni_error.generate(sv_component_name, sv_error_name, idp_self::t_shortstring);
end; $$;


--
-- Name: user_role__set_active(public.t_id, public.t_boolean); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_role__set_active(idp_self public.t_id, p_value public.t_boolean) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'adm_user';
  sv_table_name t_name = 'user_role';
  sv_column_name t_name = 'b_active';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: user_role__set_begin(public.t_id, public.t_date); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_role__set_begin(idp_self public.t_id, p_value public.t_date) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'adm_user';
  sv_table_name t_name = 'user_role';
  sv_column_name t_name = 'd_begin';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: user_role__set_end(public.t_id, public.t_date); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_role__set_end(idp_self public.t_id, p_value public.t_date) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'adm_user';
  sv_table_name t_name = 'user_role';
  sv_column_name t_name = 'd_end';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: user_role__set_role(public.t_id, public.t_id); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_role__set_role(idp_self public.t_id, p_value public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'adm_user';
  sv_table_name t_name = 'user_role';
  sv_column_name t_name = 'id_role';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: user_role__set_user(public.t_id, public.t_id); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_role__set_user(idp_self public.t_id, p_value public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'adm_user';
  sv_table_name t_name = 'user_role';
  sv_column_name t_name = 'id_user';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: user_role__validate(public.t_id); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_role__validate(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
 null;
end; $$;


--
-- Name: user_session__after_edit(public.t_id); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_session__after_edit(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_user.user_session__after_edit"
        title="Функция after_edit таблицы adm_user.user_session"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
begin
  perform adm_user.user_session__validate(idp_self);
end; $$;


--
-- Name: user_session__delete_record(public.t_id); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_session__delete_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_user.user_session__delete_record"
        title="Функция delete_record таблицы adm_user.user_session"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
begin
 delete from adm_user.user_session where id = idp_self;
end; $$;


--
-- Name: user_session; Type: TABLE; Schema: adm_user; Owner: -
--

CREATE TABLE adm_user.user_session (
    id public.t_id NOT NULL,
    id_user public.t_id NOT NULL,
    s_session_key public.t_shortstring NOT NULL,
    d_begin_time public.t_datetime NOT NULL,
    d_expired_time public.t_datetime NOT NULL,
    d_end_time public.t_datetime,
    s_token public.t_shortstring
);


--
-- Name: TABLE user_session; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON TABLE adm_user.user_session IS 'Сессии пользователей';


--
-- Name: COLUMN user_session.id; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON COLUMN adm_user.user_session.id IS 'Код';


--
-- Name: COLUMN user_session.id_user; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON COLUMN adm_user.user_session.id_user IS 'Код пользователя';


--
-- Name: COLUMN user_session.s_session_key; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON COLUMN adm_user.user_session.s_session_key IS 'Код сессии';


--
-- Name: COLUMN user_session.d_begin_time; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON COLUMN adm_user.user_session.d_begin_time IS 'ДатаВремя начала сессии';


--
-- Name: COLUMN user_session.d_expired_time; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON COLUMN adm_user.user_session.d_expired_time IS 'ДатаВремя инвалидации сессии';


--
-- Name: COLUMN user_session.d_end_time; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON COLUMN adm_user.user_session.d_end_time IS 'ДатаВремя окончания сессии';


--
-- Name: COLUMN user_session.s_token; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON COLUMN adm_user.user_session.s_token IS 'Токен доступа';


--
-- Name: user_session__get_row(public.t_id); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_session__get_row(idp_self public.t_id) RETURNS adm_user.user_session
    LANGUAGE sql
    AS $$
/*<meta object="adm_user.user_session__get_row"
        title="Функция get_row таблицы adm_user.user_session"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
  select t.* from adm_user.user_session t where t.id = idp_self;
$$;


--
-- Name: user_session__insert_record(public.t_id, public.t_shortstring, public.t_datetime, public.t_datetime); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_session__insert_record(idp_user public.t_id, sp_session_key public.t_shortstring, dp_begin_time public.t_datetime, dp_expired_time public.t_datetime) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_user.user_session__insert_record"
        title="Функция insert_record таблицы adm_user.user_session"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
declare
 rv_row adm_user.user_session%rowtype;
begin
 rv_row.id := uni_api.get_table_id('adm_user','user_session');
 rv_row.id_user := idp_user;
 rv_row.s_session_key := sp_session_key;
 rv_row.d_begin_time := dp_begin_time;
 rv_row.d_expired_time := dp_expired_time;

 insert into adm_user.user_session(id, id_user, s_session_key, d_begin_time, d_expired_time)
 values(rv_row.id, rv_row.id_user, rv_row.s_session_key, rv_row.d_begin_time, rv_row.d_expired_time);

 return rv_row.id;

end; $$;


--
-- Name: user_session__lock_record(public.t_id); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_session__lock_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_user.user_session__lock_record"
        title="Функция lock_record таблицы adm_user.user_session"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
declare
 bv_is_ok t_boolean;
 sv_component_name t_name = 'UNI';
 sv_error_name t_name = 'ENoLockedRow';
begin
 select true into bv_is_ok from adm_user.user_session where id = idp_self for update nowait;
 exception when lock_not_available then
   perform uni_error.generate(sv_component_name, sv_error_name, idp_self::t_shortstring);
end; $$;


--
-- Name: user_session__set_begin_time(public.t_id, public.t_datetime, public.t_boolean); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_session__set_begin_time(idp_self public.t_id, p_value public.t_datetime, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_user.user_session__set_begin_time"
        title="Функция setter для колонки "d_begin_time" таблицы adm_user.user_session"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'adm_user';
  sv_table_name t_name = 'user_session';
  sv_column_name t_name = 'd_begin_time';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: user_session__set_end_time(public.t_id, public.t_datetime, public.t_boolean); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_session__set_end_time(idp_self public.t_id, p_value public.t_datetime, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_user.user_session__set_end_time"
        title="Функция setter для колонки "d_end_time" таблицы adm_user.user_session"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'adm_user';
  sv_table_name t_name = 'user_session';
  sv_column_name t_name = 'd_end_time';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: user_session__set_expired_time(public.t_id, public.t_datetime, public.t_boolean); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_session__set_expired_time(idp_self public.t_id, p_value public.t_datetime, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_user.user_session__set_expired_time"
        title="Функция setter для колонки "d_expired_time" таблицы adm_user.user_session"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'adm_user';
  sv_table_name t_name = 'user_session';
  sv_column_name t_name = 'd_expired_time';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: user_session__set_session_key(public.t_id, public.t_shortstring, public.t_boolean); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_session__set_session_key(idp_self public.t_id, p_value public.t_shortstring, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_user.user_session__set_session_key"
        title="Функция setter для колонки "s_session_key" таблицы adm_user.user_session"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'adm_user';
  sv_table_name t_name = 'user_session';
  sv_column_name t_name = 's_session_key';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: user_session__set_token(public.t_id, public.t_shortstring, public.t_boolean); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_session__set_token(idp_self public.t_id, p_value public.t_shortstring, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_user.user_session__set_token"
        title="Функция setter для колонки "s_token" таблицы adm_user.user_session"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'adm_user';
  sv_table_name t_name = 'user_session';
  sv_column_name t_name = 's_token';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: user_session__set_user(public.t_id, public.t_id, public.t_boolean); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_session__set_user(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_user.user_session__set_user"
        title="Функция setter для колонки "id_user" таблицы adm_user.user_session"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'adm_user';
  sv_table_name t_name = 'user_session';
  sv_column_name t_name = 'id_user';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: user_session__validate(public.t_id); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.user_session__validate(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="adm_user.user_session__validate"
        title="Функция validate таблицы adm_user.user_session"
        author="sys"
        created="04.08.2022"
        version="1.0"
        description="">
</meta>*/
begin
 null;
end; $$;


--
-- Name: users__after_edit(public.t_id); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.users__after_edit(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
  perform adm_user.users__validate(idp_self);
end; $$;


--
-- Name: users__create_db_user(public.t_id, public.t_shortstring); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.users__create_db_user(idp_self public.t_id, sp_password public.t_shortstring DEFAULT (NULL::character varying)::public.t_shortstring) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  rv_user adm_user.users%rowtype;
  cv_query t_clob;
begin
  rv_user := adm_user.users__get_row(idp_self);
  -- создаем пользователя
  cv_query := format('create role %I password ''%I'' login', rv_user.s_name, coalesce(sp_password, rv_user.s_name));
  execute cv_query;
  -- по дефолту грантим uni_user
  cv_query := format('grant uni_user to %I', rv_user.s_name);
  execute cv_query;
end; $$;


--
-- Name: users__delete_record(public.t_id); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.users__delete_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
 delete from adm_user.users where id = idp_self;
end; $$;


--
-- Name: users__find_by_name(public.t_name); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.users__find_by_name(sp_name public.t_name) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
declare
  nv_count t_integer := 0;
  idv_self t_id;
begin
  select count(*) into nv_count from adm_user.users t where t.s_name = sp_name;
  if nv_count > 1 then
    return 0;
  end if;
  select t.id into idv_self from adm_user.users t where t.s_name = sp_name;
  return idv_self;
end;
$$;


--
-- Name: users__get_person(public.t_name); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.users__get_person(sp_name public.t_name) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
declare
  rv_user adm_user.users%rowtype;
begin
  rv_user := adm_user.users__get_row(adm_user.users__find_by_name(sp_name));
  return rv_user.id_contractor;
end;
$$;


--
-- Name: users; Type: TABLE; Schema: adm_user; Owner: -
--

CREATE TABLE adm_user.users (
    id public.t_id NOT NULL,
    s_name public.t_name NOT NULL,
    s_caption public.t_caption,
    d_registered public.t_date DEFAULT (now())::public.t_date NOT NULL,
    d_closed public.t_date,
    b_active public.t_boolean DEFAULT true NOT NULL,
    id_contractor public.t_id
);


--
-- Name: TABLE users; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON TABLE adm_user.users IS 'Пользователи';


--
-- Name: COLUMN users.id; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON COLUMN adm_user.users.id IS 'Код';


--
-- Name: COLUMN users.s_name; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON COLUMN adm_user.users.s_name IS 'Системное имя';


--
-- Name: COLUMN users.s_caption; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON COLUMN adm_user.users.s_caption IS 'Наименование';


--
-- Name: COLUMN users.d_registered; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON COLUMN adm_user.users.d_registered IS 'Дата регистрации пользователя';


--
-- Name: COLUMN users.d_closed; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON COLUMN adm_user.users.d_closed IS 'Дата блокировки пользователя';


--
-- Name: COLUMN users.b_active; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON COLUMN adm_user.users.b_active IS 'Активный (Да/Нет)';


--
-- Name: COLUMN users.id_contractor; Type: COMMENT; Schema: adm_user; Owner: -
--

COMMENT ON COLUMN adm_user.users.id_contractor IS 'Код контрагента';


--
-- Name: users__get_row(public.t_id); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.users__get_row(idp_self public.t_id) RETURNS adm_user.users
    LANGUAGE sql
    AS $$
  select t.* from adm_user.users t where t.id = idp_self;
$$;


--
-- Name: users__insert_record(public.t_name); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.users__insert_record(sp_name public.t_name) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
declare
 rv_row adm_user.users%rowtype;
begin
 rv_row.id := uni_api.get_table_id('adm_user','users');
 rv_row.s_name := sp_name;

 insert into adm_user.users(id, s_name)
 values(rv_row.id, rv_row.s_name);

 return rv_row.id;

end; $$;


--
-- Name: users__lock_record(public.t_id); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.users__lock_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
 bv_is_ok t_boolean;
 sv_component_name t_name = 'UNI';
 sv_error_name t_name = 'ENoLockedRow';
begin
 select true into bv_is_ok from adm_user.users where id = idp_self for update nowait;
 exception when lock_not_available then
   perform uni_error.generate(sv_component_name, sv_error_name, idp_self::t_shortstring);
end; $$;


--
-- Name: users__register_new_user(public.t_name, public.t_caption, public.t_shortstring); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.users__register_new_user(sp_user_name public.t_name, sp_user_caption public.t_caption, sp_password public.t_shortstring DEFAULT (NULL::character varying)::public.t_shortstring) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  idv_user adm_user.users.id%type;
begin
  -- создаем нового пользователя в uni
  idv_user := adm_user.users__insert_record(sp_user_name);
  perform adm_user.users__set_caption(idv_user, sp_user_caption);
  perform adm_user.users__after_edit(idv_user);
  -- создаем для него пользователя в db
  perform adm_user.users__create_db_user(idv_user, sp_password);
end; $$;


--
-- Name: users__set_active(public.t_id, public.t_boolean); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.users__set_active(idp_self public.t_id, p_value public.t_boolean) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'adm_user';
  sv_table_name t_name = 'users';
  sv_column_name t_name = 'b_active';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: users__set_caption(public.t_id, public.t_caption); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.users__set_caption(idp_self public.t_id, p_value public.t_caption) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'adm_user';
  sv_table_name t_name = 'users';
  sv_column_name t_name = 's_caption';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: users__set_closed(public.t_id, public.t_date); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.users__set_closed(idp_self public.t_id, p_value public.t_date) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'adm_user';
  sv_table_name t_name = 'users';
  sv_column_name t_name = 'd_closed';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: users__set_contractor(public.t_id, public.t_id); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.users__set_contractor(idp_self public.t_id, p_value public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'adm_user';
  sv_table_name t_name = 'users';
  sv_column_name t_name = 'id_contractor';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: users__set_name(public.t_id, public.t_name); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.users__set_name(idp_self public.t_id, p_value public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'adm_user';
  sv_table_name t_name = 'users';
  sv_column_name t_name = 's_name';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: users__set_registered(public.t_id, public.t_date); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.users__set_registered(idp_self public.t_id, p_value public.t_date) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'adm_user';
  sv_table_name t_name = 'users';
  sv_column_name t_name = 'd_registered';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: users__validate(public.t_id); Type: FUNCTION; Schema: adm_user; Owner: -
--

CREATE FUNCTION adm_user.users__validate(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
 null;
end; $$;


--
-- Name: get_table_id(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.get_table_id(sp_schema public.t_name, sp_table public.t_name) RETURNS bigint
    LANGUAGE sql
    AS $$
  select nextval(format('%I.seq_%I', sp_schema, sp_table));
$$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_boolean, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_boolean, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_caption, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_caption, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_clob, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_clob, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_code, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_code, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_date, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_date, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_datetime, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_datetime, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_description, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_description, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_float, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_float, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_html, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_html, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_id, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_id, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;
$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_integer, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_integer, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_json, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_json, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_longstring, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_longstring, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_money, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_money, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_name, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_name, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_shortstring, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_shortstring, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_xml, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_xml, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: component__after_edit(public.t_id); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__after_edit(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
  perform uni_component.component__validate(idp_self);
end; $$;


--
-- Name: component__delete_record(public.t_id); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__delete_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
 delete from uni_component.component where id = idp_self;
end; $$;


--
-- Name: component__find_by_name(public.t_name); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__find_by_name(sp_name public.t_name) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
declare
  nv_count t_integer := 0;
  idv_self t_id;
begin
  select count(*) into nv_count from uni_component.component t where t.s_name = sp_name;
  if nv_count > 1 then
    return 0;
  end if;
  select t.id into idv_self from uni_component.component t where t.s_name = sp_name;
  return idv_self;
end;
$$;


--
-- Name: component; Type: TABLE; Schema: uni_component; Owner: -
--

CREATE TABLE uni_component.component (
    id public.t_id NOT NULL,
    s_name public.t_name NOT NULL,
    s_caption public.t_caption,
    s_description public.t_description,
    id_parent public.t_id
);


--
-- Name: TABLE component; Type: COMMENT; Schema: uni_component; Owner: -
--

COMMENT ON TABLE uni_component.component IS 'Компоненты';


--
-- Name: COLUMN component.id; Type: COMMENT; Schema: uni_component; Owner: -
--

COMMENT ON COLUMN uni_component.component.id IS 'Код';


--
-- Name: COLUMN component.s_name; Type: COMMENT; Schema: uni_component; Owner: -
--

COMMENT ON COLUMN uni_component.component.s_name IS 'Системное имя';


--
-- Name: COLUMN component.s_caption; Type: COMMENT; Schema: uni_component; Owner: -
--

COMMENT ON COLUMN uni_component.component.s_caption IS 'Наименование';


--
-- Name: COLUMN component.s_description; Type: COMMENT; Schema: uni_component; Owner: -
--

COMMENT ON COLUMN uni_component.component.s_description IS 'Описание';


--
-- Name: COLUMN component.id_parent; Type: COMMENT; Schema: uni_component; Owner: -
--

COMMENT ON COLUMN uni_component.component.id_parent IS 'Код родительского компонента';


--
-- Name: component__get_row(public.t_id); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__get_row(idp_self public.t_id) RETURNS uni_component.component
    LANGUAGE sql
    AS $$
  select t.* from uni_component.component t where t.id = idp_self;
$$;


--
-- Name: component__insert_record(public.t_name); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__insert_record(sp_name public.t_name) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
declare
 rv_row uni_component.component%rowtype;
begin
 rv_row.id := uni_api.get_table_id('uni_component','component');
 rv_row.s_name := sp_name;

 insert into uni_component.component(id, s_name)
 values(rv_row.id, rv_row.s_name);

 return rv_row.id;

end; $$;


--
-- Name: component__lock_record(public.t_id); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__lock_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
 bv_is_ok t_boolean;
 sv_component_name t_name = 'UNI';
 sv_error_name t_name = 'ENoLockedRow';
begin
 select true into bv_is_ok from uni_component.component where id = idp_self for update nowait;
 exception when lock_not_available then
   perform uni_error.generate(sv_component_name, sv_error_name, idp_self::t_shortstring);
end; $$;


--
-- Name: component__set_caption(public.t_id, public.t_caption); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__set_caption(idp_self public.t_id, p_value public.t_caption) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_component';
  sv_table_name t_name = 'component';
  sv_column_name t_name = 's_caption';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: component__set_description(public.t_id, public.t_description); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__set_description(idp_self public.t_id, p_value public.t_description) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_component';
  sv_table_name t_name = 'component';
  sv_column_name t_name = 's_description';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: component__set_name(public.t_id, public.t_name); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__set_name(idp_self public.t_id, p_value public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_component';
  sv_table_name t_name = 'component';
  sv_column_name t_name = 's_name';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: component__set_parent(public.t_id, public.t_id); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__set_parent(idp_self public.t_id, p_value public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_component';
  sv_table_name t_name = 'component';
  sv_column_name t_name = 'id_parent';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: component__validate(public.t_id); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__validate(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
 null;
end; $$;


--
-- Name: endl(); Type: FUNCTION; Schema: uni_const; Owner: -
--

CREATE FUNCTION uni_const.endl() RETURNS character varying
    LANGUAGE sql IMMUTABLE LEAKPROOF
    AS $$
	select chr(10) as endl;
$$;


--
-- Name: max_date(); Type: FUNCTION; Schema: uni_const; Owner: -
--

CREATE FUNCTION uni_const.max_date() RETURNS public.t_date
    LANGUAGE sql IMMUTABLE LEAKPROOF
    AS $$
  select to_date('31.12.4096','dd.mm.yyyy')::t_date as d_date
$$;


--
-- Name: min_date(); Type: FUNCTION; Schema: uni_const; Owner: -
--

CREATE FUNCTION uni_const.min_date() RETURNS public.t_date
    LANGUAGE sql IMMUTABLE LEAKPROOF
    AS $$
  select to_date('01.01.0001','dd.mm.yyyy')::t_date as d_date
$$;


--
-- Name: reg_col_type(); Type: FUNCTION; Schema: uni_const; Owner: -
--

CREATE FUNCTION uni_const.reg_col_type() RETURNS character varying
    LANGUAGE sql IMMUTABLE LEAKPROOF
    AS $$
	select '^(\w{1,4})_(.+)' as regular;
$$;


--
-- Name: reg_replace(public.t_name); Type: FUNCTION; Schema: uni_const; Owner: -
--

CREATE FUNCTION uni_const.reg_replace(sp_prefix public.t_name) RETURNS character varying
    LANGUAGE sql IMMUTABLE LEAKPROOF
    AS $$
  select '\1'||Coalesce(sp_prefix,'p')||'_\2';
$$;


--
-- Name: error__after_edit(public.t_id); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__after_edit(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
  perform uni_error.error__validate(idp_self);
  update uni_error.error set d_edited = current_timestamp where id = idp_self;
end; $$;


--
-- Name: error__delete_record(public.t_id); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__delete_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
 delete from uni_error.error where id = idp_self;
end; $$;


--
-- Name: error__find_by_name(public.t_name); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__find_by_name(sp_name public.t_name) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
declare
  nv_count t_integer := 0;
  idv_self t_id;
begin
  select count(*) into nv_count from uni_error.error t where t.s_name = sp_name;
  if nv_count > 1 then
    return 0;
  end if;
  select t.id into idv_self from uni_error.error t where t.s_name = sp_name;
  return idv_self;
end;
$$;


--
-- Name: error; Type: TABLE; Schema: uni_error; Owner: -
--

CREATE TABLE uni_error.error (
    id public.t_id NOT NULL,
    s_name public.t_name NOT NULL,
    s_caption public.t_caption,
    s_description public.t_description,
    d_created public.t_datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
    d_edited public.t_datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
    id_component public.t_id NOT NULL
);


--
-- Name: TABLE error; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON TABLE uni_error.error IS 'Ошибки';


--
-- Name: COLUMN error.id; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON COLUMN uni_error.error.id IS 'Код';


--
-- Name: COLUMN error.s_name; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON COLUMN uni_error.error.s_name IS 'Системное имя';


--
-- Name: COLUMN error.s_caption; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON COLUMN uni_error.error.s_caption IS 'Наименование';


--
-- Name: COLUMN error.s_description; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON COLUMN uni_error.error.s_description IS 'Описание';


--
-- Name: COLUMN error.d_created; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON COLUMN uni_error.error.d_created IS 'Дата создания';


--
-- Name: COLUMN error.d_edited; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON COLUMN uni_error.error.d_edited IS 'Дата последнего редактирования';


--
-- Name: COLUMN error.id_component; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON COLUMN uni_error.error.id_component IS 'Код компонента';


--
-- Name: error__get_row(public.t_id); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__get_row(idp_self public.t_id) RETURNS uni_error.error
    LANGUAGE sql
    AS $$
  select t.* from uni_error.error t where t.id = idp_self;
$$;


--
-- Name: error__insert_record(public.t_name, public.t_id); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__insert_record(sp_name public.t_name, idp_component public.t_id) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
declare
 rv_row uni_error.error%rowtype;
begin
 rv_row.id := uni_api.get_table_id('uni_error','error');
 rv_row.s_name := sp_name;
 rv_row.id_component := idp_component;
 rv_row.d_created := now()::t_datetime;
 rv_row.d_edited := now()::t_datetime;

 insert into uni_error.error(id, s_name, id_component, d_created, d_edited)
 values(rv_row.id, rv_row.s_name, rv_row.id_component, rv_row.d_created, rv_row.d_edited);

 return rv_row.id;

end; $$;


--
-- Name: error__lock_record(public.t_id); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__lock_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
 bv_is_ok t_boolean;
 sv_component_name t_name = 'UNI';
 sv_error_name t_name = 'ENoLockedRow';
begin
 select true into bv_is_ok from uni_error.error where id = idp_self for update nowait;
 exception when lock_not_available then
   perform uni_error.generate(sv_component_name, sv_error_name, idp_self::t_shortstring);
end; $$;


--
-- Name: error__set_caption(public.t_id, public.t_caption); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__set_caption(idp_self public.t_id, p_value public.t_caption) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_error';
  sv_table_name t_name = 'error';
  sv_column_name t_name = 's_caption';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: error__set_component(public.t_id, public.t_id); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__set_component(idp_self public.t_id, p_value public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_error';
  sv_table_name t_name = 'error';
  sv_column_name t_name = 'id_component';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: error__set_created(public.t_id, public.t_datetime); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__set_created(idp_self public.t_id, p_value public.t_datetime) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_error';
  sv_table_name t_name = 'error';
  sv_column_name t_name = 'd_created';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: error__set_description(public.t_id, public.t_description); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__set_description(idp_self public.t_id, p_value public.t_description) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_error';
  sv_table_name t_name = 'error';
  sv_column_name t_name = 's_description';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: error__set_edited(public.t_id, public.t_datetime); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__set_edited(idp_self public.t_id, p_value public.t_datetime) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_error';
  sv_table_name t_name = 'error';
  sv_column_name t_name = 'd_edited';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: error__set_name(public.t_id, public.t_name); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__set_name(idp_self public.t_id, p_value public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_error';
  sv_table_name t_name = 'error';
  sv_column_name t_name = 's_name';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: error__validate(public.t_id); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__validate(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
 null;
end; $$;


--
-- Name: generate(public.t_name, public.t_name, public.t_shortstring[]); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.generate(sp_component public.t_name, sp_name public.t_name, VARIADIC params public.t_shortstring[]) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_error text;
  sv_stack text;
  param text;
begin
  -- Собираем данные из компонент таблицы с применением шаблонов ошибки
  begin
    select error.s_error_dc
    into sv_error
    from uni_error.component_errors error
    where Upper(error.s_component_mc) = Upper(sp_component)
      and Upper(error.s_error_mc) = Upper(sp_name);
  end;
  -- Если мы такого не нашли, то использовать первый параметр, как сообщение об ошибке
  if sv_error is null then
    sv_error := '%1';
  end if;
  -- Формируем по шаблону 
  declare
    nv_count t_integer := 1;
  begin
    foreach param in array params
    loop
      sv_error := Replace(sv_error, '%'||nv_count, param);
      nv_count := nv_count + 1;
    end loop;
  end;
  raise exception using message = sv_error;
end;$$;


--
-- Name: generate_after_edit(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_after_edit(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
begin
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__after_edit', sv_schemaname, sv_tablename);
  sv_text := sv_text||format('(idp_self %I.%I.id%%type)',sv_schemaname, sv_tablename)||uni_const.endl();
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||'returns void'||uni_const.endl();
    sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__after_edit"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция after_edit таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  --begin
  declare
    sv_cred_time text;
  begin
    sv_text := sv_text||'begin'||uni_const.endl();
    sv_text := sv_text||format('  perform %I.%I__validate(idp_self);', sv_schemaname, sv_tablename)||uni_const.endl();
    begin
      select string_agg(db_tab_col.column_name||' = current_timestamp',',')
      into sv_cred_time
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) in ('d_edited');
    end;
    if Coalesce(sv_cred_time, 'None') != 'None' then
      sv_text := sv_text||format('  update %I.%I set '||sv_cred_time||' where id = idp_self;', sv_schemaname, sv_tablename)||uni_const.endl();
    end if;
  end;
  --end
  begin
    sv_text := sv_text||'end; $$;'||uni_const.endl()||uni_const.endl();
  end;
  return sv_text;
end;$_$;


--
-- Name: generate_delete_record(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_delete_record(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
begin
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__delete_record',sv_schemaname,sv_tablename);
  sv_text := sv_text||format('(idp_self %I.%I.id%%type)',sv_schemaname,sv_tablename)||uni_const.endl();
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||'returns void'||uni_const.endl();
    sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__delete_record"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция delete_record таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  --begin
  begin
    sv_text := sv_text||'begin'||uni_const.endl();
    sv_text := sv_text||format(' delete from %I.%I where id = idp_self;',sp_schemaname,sp_tablename)||uni_const.endl();
  end;
  --end
  begin
    sv_text := sv_text||'end; $$;'||uni_const.endl()||uni_const.endl();
  end;
  return sv_text;
end;$_$;


--
-- Name: generate_find_by_code(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_find_by_code(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_tablename t_name := lower(sp_tablename);
  sv_schemaname t_name := lower(sp_schemaname);
begin
  --sv_text := sv_text||'drop function '||sp_schemaname||'.'||sp_tablename||'_FindByName;'||uni_const.endl();
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__find_by_code',sv_schemaname,sv_tablename);
  sv_text := sv_text||format('(sp_code %I.%I.s_code%%type)',sv_schemaname,sv_tablename)||uni_const.endl();
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||format('returns %I.%I.id%%type',sv_schemaname,sv_tablename)||uni_const.endl();
    sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__find_by_code"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция find_by_code таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  -- declare
  sv_text := sv_text||'declare'||uni_const.endl();
  sv_text := sv_text||'  nv_count t_integer := 0;'||uni_const.endl();
  sv_text := sv_text||'  idv_self t_id;'||uni_const.endl();
  -- begin
  sv_text := sv_text||'begin'||uni_const.endl();
  sv_text := sv_text||format('  select count(*) into nv_count from %I.%I t where t.s_code = sp_code;',sv_schemaname,sv_tablename)||uni_const.endl();
  sv_text := sv_text||'  if nv_count > 1 then'||uni_const.endl();
  sv_text := sv_text||'    return 0;'||uni_const.endl();
  sv_text := sv_text||'  end if;'||uni_const.endl();
  sv_text := sv_text||format('  select t.id into idv_self from %I.%I t where t.s_code = sp_code;',sv_schemaname,sv_tablename)||uni_const.endl();
  sv_text := sv_text||'  return idv_self;'||uni_const.endl();
  --end
  sv_text := sv_text||'end;'||uni_const.endl();
  begin
    sv_text := sv_text||'$$;'||uni_const.endl()||uni_const.endl();
  end;
  return sv_text;
end; 
$_$;


--
-- Name: generate_find_by_name(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_find_by_name(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
begin
  --sv_text := sv_text||'drop function '||sp_schemaname||'.'||sp_tablename||'_FindByName;'||uni_const.endl();
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__find_by_name',sv_schemaname,sv_tablename);
  sv_text := sv_text||format('(sp_name %I.%I.s_name%%type)',sv_schemaname,sv_tablename)||uni_const.endl();
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||format('returns %I.%I.id%%type',sv_schemaname,sv_tablename)||uni_const.endl();
    sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__find_by_name"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция find_by_name таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  -- declare
  sv_text := sv_text||'declare'||uni_const.endl();
  sv_text := sv_text||'  nv_count t_integer := 0;'||uni_const.endl();
  sv_text := sv_text||'  idv_self t_id;'||uni_const.endl();
  -- begin
  sv_text := sv_text||'begin'||uni_const.endl();
  sv_text := sv_text||format('  select count(*) into nv_count from %I.%I t where t.s_name = sp_name;',sv_schemaname,sv_tablename)||uni_const.endl();
  sv_text := sv_text||'  if nv_count > 1 then'||uni_const.endl();
  sv_text := sv_text||'    return 0;'||uni_const.endl();
  sv_text := sv_text||'  end if;'||uni_const.endl();
  sv_text := sv_text||format('  select t.id into idv_self from %I.%I t where t.s_name = sp_name;',sv_schemaname,sv_tablename)||uni_const.endl();
  --end
  sv_text := sv_text||'  return idv_self;'||uni_const.endl();
  sv_text := sv_text||'end;'||uni_const.endl();
  begin
    sv_text := sv_text||'$$;'||uni_const.endl()||uni_const.endl();
  end;
  return sv_text;
end; 
$_$;


--
-- Name: generate_get_row(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_get_row(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
begin
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__get_row',sv_schemaname,sv_tablename);
  sv_text := sv_text||format('(idp_self %I.%I.id%%Type)',sv_schemaname,sv_tablename)||uni_const.endl();
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||format('returns %I.%I',sv_schemaname,sv_tablename)||uni_const.endl();
    sv_text := sv_text||'language sql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__get_row"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция get_row таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  --declare
  begin
    sv_text := sv_text||format('  select t.* from %I.%I t where t.id = idp_self;',sv_schemaname,sv_tablename)||uni_const.endl();
  end;
  --end
  begin
    sv_text := sv_text||'$$;'||uni_const.endl()||uni_const.endl();
  end;
  return sv_text;
end; $_$;


--
-- Name: generate_grants(public.t_name, public.t_name, public.t_shortstringarray); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_grants(sp_schemaname public.t_name, sp_tablename public.t_name, sap_roles public.t_shortstringarray) RETURNS text
    LANGUAGE plpgsql
    AS $$
declare
  sv_text text := '';
  sv_schemanname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
  curv_data record;
  grant_role t_shortstring;
begin
  for curv_data in
  (
    select NSP.nspname as s_schemaname
          ,Proc.proName as s_procname
          ,pg_catalog.pg_get_function_identity_arguments(Proc.oid) as s_procparams
    from pg_catalog.pg_namespace NSP
    inner join pg_catalog.pg_proc Proc on Proc.pronamespace = NSP.oid
    where lower(NSP.nspname) = sv_schemanname
      and lower(Proc.proname) like sv_tablename||'_%'
  )
  loop
    foreach grant_role in array sap_roles::character varying(255)[]
    loop
      sv_text := sv_text||format('grant execute on function %I.%I(%s) to %I;',curv_data.s_schemaname,curv_data.s_procname, curv_data.s_procparams, grant_role)||uni_const.endl();
    end loop;
  end loop;
  return sv_text;
end;$$;


--
-- Name: generate_insert_record(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_insert_record(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
begin
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__insert_record',sv_schemaname,sv_tablename);
  -- Необходимые параметры (not null)
  declare
    curv_column record;
  begin
    -- Открываем блок параметров
    sv_text := sv_text||uni_const.endl()||'('||uni_const.endl();
    for curv_column in
      select row_number() over() as rownum
            ,count(*) over() as all_count
            ,db_tab_col.*
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) not in('id','d_created','d_edited')
        and db_tab_col.column_default is null
        and db_tab_col.is_nullable = 'NO'
    loop
      sv_text := sv_text||' '||case when curv_column.rownum = 1 then ' '
                               else ',' end
                        ||regexp_replace(curv_column.column_name
                                        ,uni_const.reg_col_type()
                                        ,uni_const.reg_replace('p'))
                        ||' '
                        ||format('%I.%I.%I%%type',sp_schemaname,sp_tablename,curv_column.column_name)
                        ||case when curv_column.rownum = curv_column.all_count then ''
                          else uni_const.endl() end;
    end loop;
    -- закрываем блок параметров
    sv_text := sv_text||uni_const.endl()||')'||uni_const.endl();
  end;
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||format(' returns %I.%I.id%%type',sv_schemaname,sv_tablename)||uni_const.endl();
    sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__insert_record"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция insert_record таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  --Тело функции
  --declare
  begin
    sv_text := sv_text||'declare'||uni_const.endl();
    sv_text := sv_text||format(' rv_row %I.%I%%rowtype;',sv_schemaname,sv_tablename)||uni_const.endl();
  end;
  --begin
  declare
    curv_column record;
  begin
    sv_text := sv_text||'begin'||uni_const.endl();
    -- Устанавливаем все системные поля и поля которые нужны для инсерта
    sv_text := sv_text||format(' rv_row.id := uni_api.get_table_id(''%I'',''%I'');',sv_schemaname,sv_tablename)||uni_const.endl();
    for curv_column in
      select row_number() over() as rownum
            ,count(*) over() as all_count
            ,db_tab_col.*
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) not in('id','d_created','d_edited')
        and db_tab_col.column_default is null
        and db_tab_col.is_nullable = 'NO'
    loop
      sv_text := sv_text||format(' rv_row.%I := %I;',curv_column.column_name,regexp_replace(curv_column.column_name
                                                                                          ,uni_const.reg_col_type()
                                                                                          ,uni_const.reg_replace('p')))
                        ||uni_const.endl();
    end loop;
    -- Добрасываем редактирование дат создани я редактирования
    for curv_column in
      select row_number() over() as rownum
            ,count(*) over() as all_count
            ,db_tab_col.*
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) in('d_created','d_edited')
    loop
      sv_text := sv_text||format(' rv_row.%I := now()::t_datetime;',curv_column.column_name)
                        ||uni_const.endl();
    end loop;
    -- Пишем вставку
    sv_text := sv_text||uni_const.endl();
    sv_text := sv_text||format(' insert into %I.%I(id',sv_schemaname,sv_tablename);
    for curv_column in
      select row_number() over() as rownum
            ,count(*) over() as all_count
            ,db_tab_col.*
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) not in('id','d_created','d_edited')
        and db_tab_col.column_default is null
        and db_tab_col.is_nullable = 'NO'
    loop
      sv_text := sv_text||', '||curv_column.column_name;
    end loop;
    for curv_column in
      select row_number() over() as rownum
            ,count(*) over() as all_count
            ,db_tab_col.*
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) in('d_created','d_edited')
    loop
      sv_text := sv_text||', '||curv_column.column_name;
    end loop;
    sv_text := sv_text||')'||uni_const.endl();
    sv_text := sv_text||' values(rv_row.id';
    for curv_column in
      select row_number() over() as rownum
            ,count(*) over() as all_count
            ,db_tab_col.*
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) not in('id','d_created','d_edited')
        and db_tab_col.column_default is null
        and db_tab_col.is_nullable = 'NO'
    loop
      sv_text := sv_text||', rv_row.'||curv_column.column_name;
    end loop;
    for curv_column in
      select row_number() over() as rownum
            ,count(*) over() as all_count
            ,db_tab_col.*
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) in('d_created','d_edited')
    loop
      sv_text := sv_text||', rv_row.'||curv_column.column_name;
    end loop;
    sv_text := sv_text||');'||uni_const.endl();
    sv_text := sv_text||uni_const.endl();
    sv_text := sv_text||' return rv_row.id;'||uni_const.endl();
    sv_text := sv_text||uni_const.endl();
  end;
  --end
  begin
    sv_text := sv_text||'end; $$;'||uni_const.endl()||uni_const.endl();
  end;
  -- Возвращаем значение заготовки
  return sv_text;
end;$_$;


--
-- Name: generate_lock_record(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_lock_record(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
begin
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__lock_record',sv_schemaname,sv_tablename);
  sv_text := sv_text||format('(idp_self %I.%I.id%%type)',sv_schemaname,sv_tablename)||uni_const.endl();
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||'returns void'||uni_const.endl();
    sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__lock_record"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция lock_record таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  --declare
  begin
    sv_text := sv_text||'declare'||uni_const.endl();
    sv_text := sv_text||' bv_is_ok t_boolean;'||uni_const.endl();
    sv_text := sv_text||' sv_component_name t_name = ''UNI'';'||uni_const.endl();
    sv_text := sv_text||' sv_error_name t_name = ''ENoLockedRow'';'||uni_const.endl();
  end;
  --begin
  begin
    sv_text := sv_text||'begin'||uni_const.endl();
    sv_text := sv_text||format(' select true into bv_is_ok from %I.%I where id = idp_self for update nowait;',sv_schemaname,sv_tablename)||uni_const.endl();
    sv_text := sv_text||' exception when lock_not_available then'||uni_const.endl();
    sv_text := sv_text||'   perform uni_error.generate(sv_component_name, sv_error_name, idp_self::t_shortstring);'||uni_const.endl();
  end;
  --end
  begin
    sv_text := sv_text||'end; $$;'||uni_const.endl()||uni_const.endl();
  end;
  return sv_text;
end;$_$;


--
-- Name: generate_setters(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_setters(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
  curv_column record;
begin
  for curv_column in
    select row_number() over() as rownum
          ,count(*) over() as all_count
          ,db_tab_col.*
    from information_schema.columns db_tab_col
    where lower(db_tab_col.table_schema) = sv_schemaname
      and lower(db_tab_col.table_name) = sv_tablename
      and lower(db_tab_col.column_name) not in('id')
  loop
    sv_text := sv_text||'create or replace function '||sv_schemaname||'.'||sv_tablename
                      ||'__set_'||lower(regexp_replace(curv_column.column_name
                                                      ,uni_const.reg_col_type()
                                                      ,'\2'));
    sv_text := sv_text||'(idp_self '||sp_schemaname||'.'||sp_tablename||'.id%type,'
                      ||' p_value '||sp_schemaname||'.'||sp_tablename||'.'||curv_column.column_name||'%type,'
                      ||' bp_internal_call t_boolean default false)'||uni_const.endl();
    -- Определение возвращаемого значения и языка функции
    begin
      sv_text := sv_text||'returns void'||uni_const.endl();
      sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
      sv_text := sv_text||format('/*<meta object="%I.%I__set_'||lower(regexp_replace(curv_column.column_name
                                                      ,uni_const.reg_col_type()
                                                      ,'\2'))||'"',sv_schemaname, sv_tablename)||uni_const.endl();
      sv_text := sv_text||format('        title="Функция setter для колонки "%I" таблицы %I.%I"',curv_column.column_name,sv_schemaname, sv_tablename)||uni_const.endl();
      sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
      sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
      sv_text := sv_text||'        version="1.0"'||uni_const.endl();
      sv_text := sv_text||'        description="">'||uni_const.endl();
      sv_text := sv_text||'</meta>*/'||uni_const.endl();
    end;
    --declare
    begin
      sv_text := sv_text||'declare'||uni_const.endl();
      sv_text := sv_text||'  sv_schema_name t_name = '''||sv_schemaname||''';'||uni_const.endl();
      sv_text := sv_text||'  sv_table_name t_name = '''||sv_tablename||''';'||uni_const.endl();
      sv_text := sv_text||'  sv_column_name t_name = '''||curv_column.column_name||''';'||uni_const.endl();
      sv_text := sv_text||'  sv_identity_field t_name = ''id'';'||uni_const.endl();
    end;
    --begin
    begin
      sv_text := sv_text||'begin'||uni_const.endl();
      sv_text := sv_text||' perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name';
      sv_text := sv_text||',idp_self, p_value, sv_identity_field);'||uni_const.endl();
    end;
    --end
    begin
      sv_text := sv_text||'end; $$;'||uni_const.endl()||uni_const.endl();
    end;
  end loop;
  return sv_text;
end;$_$;


--
-- Name: generate_table_api(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_table_api(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
begin
  --Do
  sv_text := sv_text||'do'||uni_const.endl()||'$DO$'||uni_const.endl();
  sv_text := sv_text||'begin'||uni_const.endl();
  -- GetRow
  sv_text := sv_text||uni_generator.generate_get_row(sp_schemaname, sp_tablename);
  -- FindByName
  declare
    bv_exists_name t_boolean;
  begin
    begin
      select true
      into bv_exists_name
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = lower(sp_schemaname)
        and lower(db_tab_col.table_name) = lower(sp_tablename)
        and lower(db_tab_col.column_name) in ('s_name');
    end;
    if Coalesce(bv_exists_name, false) = true then
      sv_text := sv_text||uni_generator.generate_find_by_name(sp_schemaname, sp_tablename);
    end if;
  end;
  -- FindByCode
  declare
    bv_exists_code t_boolean;
  begin
    begin
      select true
      into bv_exists_code
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = lower(sp_schemaname)
        and lower(db_tab_col.table_name) = lower(sp_tablename)
        and lower(db_tab_col.column_name) in ('s_code');
    end;
    if Coalesce(bv_exists_code, false) = true then
      sv_text := sv_text||uni_generator.generate_find_by_code(sp_schemaname, sp_tablename);
    end if;
  end;
  -- LockRecord
  sv_text := sv_text||uni_generator.generate_lock_record(sp_schemaname, sp_tablename);
  -- InsertRecord
  sv_text := sv_text||uni_generator.generate_insert_record(sp_schemaname, sp_tablename); 
  -- DeleteRecord
  sv_text := sv_text||uni_generator.generate_delete_record(sp_schemaname, sp_tablename);
  -- Setters
  sv_text := sv_text||uni_generator.generate_setters(sp_schemaname, sp_tablename);
  -- Validate
  sv_text := sv_text||uni_generator.generate_validate(sp_schemaname, sp_tablename);
  -- AfterEdit
  sv_text := sv_text||uni_generator.generate_after_edit(sp_schemaname, sp_tablename);
  sv_text := sv_text||'end;'||uni_const.endl();
  sv_text := sv_text||'$DO$;';
  return sv_text;

end;$_$;


--
-- Name: generate_validate(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_validate(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
begin
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__validate',sv_schemaname,sv_tablename);
  sv_text := sv_text||format('(idp_self %I.%I.id%%type)',sv_schemaname,sv_tablename)||uni_const.endl();
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||'returns void'||uni_const.endl();
    sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__validate"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция validate таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  --begin
  begin
    sv_text := sv_text||'begin'||uni_const.endl();
    sv_text := sv_text||' null;'||uni_const.endl();
  end;
  --end
  begin
    sv_text := sv_text||'end; $$;'||uni_const.endl()||uni_const.endl();
  end;
  return sv_text;
end;$_$;


--
-- Name: seq_privelegy; Type: SEQUENCE; Schema: adm_privelegy; Owner: -
--

CREATE SEQUENCE adm_privelegy.seq_privelegy
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_role_privs; Type: SEQUENCE; Schema: adm_role; Owner: -
--

CREATE SEQUENCE adm_role.seq_role_privs
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_role_relation; Type: SEQUENCE; Schema: adm_role; Owner: -
--

CREATE SEQUENCE adm_role.seq_role_relation
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_roles; Type: SEQUENCE; Schema: adm_role; Owner: -
--

CREATE SEQUENCE adm_role.seq_roles
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_user_role; Type: SEQUENCE; Schema: adm_user; Owner: -
--

CREATE SEQUENCE adm_user.seq_user_role
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_users; Type: SEQUENCE; Schema: adm_user; Owner: -
--

CREATE SEQUENCE adm_user.seq_users
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_component; Type: SEQUENCE; Schema: uni_component; Owner: -
--

CREATE SEQUENCE uni_component.seq_component
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: component_errors; Type: VIEW; Schema: uni_error; Owner: -
--

CREATE VIEW uni_error.component_errors AS
 WITH RECURSIVE componentall AS (
         SELECT componentin.id AS idroot,
            componentin.id,
            componentin.s_name AS sname,
            componentin.s_caption AS scaption
           FROM uni_component.component componentin
        UNION ALL
         SELECT componentall.idroot,
            componentin.id,
            componentin.s_name AS sname,
            componentin.s_caption AS scaption
           FROM (uni_component.component componentin
             JOIN componentall ON (((componentall.id)::bigint = (componentin.id_parent)::bigint)))
        )
 SELECT component.id AS id_component,
    component.sname AS s_component_mc,
    component.scaption AS s_component_hl,
    error.id AS id_error,
    error.s_name AS s_error_mc,
    error.s_caption AS s_error_hl,
    error.s_description AS s_error_dc
   FROM (componentall component
     LEFT JOIN uni_error.error error ON (((error.id_component)::bigint = (component.idroot)::bigint)));


--
-- Name: seq_error; Type: SEQUENCE; Schema: uni_error; Owner: -
--

CREATE SEQUENCE uni_error.seq_error
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Data for Name: privelegy; Type: TABLE DATA; Schema: adm_privelegy; Owner: -
--

COPY adm_privelegy.privelegy (id, s_name, s_caption, d_begin, d_end) FROM stdin;
\.
COPY adm_privelegy.privelegy (id, s_name, s_caption, d_begin, d_end) FROM '$$PATH$$/3286.dat';

--
-- Data for Name: role_privs; Type: TABLE DATA; Schema: adm_role; Owner: -
--

COPY adm_role.role_privs (id, id_role, id_privelegy, d_begin, d_end) FROM stdin;
\.
COPY adm_role.role_privs (id, id_role, id_privelegy, d_begin, d_end) FROM '$$PATH$$/3288.dat';

--
-- Data for Name: role_relation; Type: TABLE DATA; Schema: adm_role; Owner: -
--

COPY adm_role.role_relation (id, id_parent_role, id_child_role, d_begin, d_end, b_active) FROM stdin;
\.
COPY adm_role.role_relation (id, id_parent_role, id_child_role, d_begin, d_end, b_active) FROM '$$PATH$$/3274.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: adm_role; Owner: -
--

COPY adm_role.roles (id, s_name, s_caption, d_begin, d_end, b_active) FROM stdin;
\.
COPY adm_role.roles (id, s_name, s_caption, d_begin, d_end, b_active) FROM '$$PATH$$/3275.dat';

--
-- Data for Name: user_role; Type: TABLE DATA; Schema: adm_user; Owner: -
--

COPY adm_user.user_role (id, id_user, id_role, d_begin, d_end, b_active) FROM stdin;
\.
COPY adm_user.user_role (id, id_user, id_role, d_begin, d_end, b_active) FROM '$$PATH$$/3276.dat';

--
-- Data for Name: user_session; Type: TABLE DATA; Schema: adm_user; Owner: -
--

COPY adm_user.user_session (id, id_user, s_session_key, d_begin_time, d_expired_time, d_end_time, s_token) FROM stdin;
\.
COPY adm_user.user_session (id, id_user, s_session_key, d_begin_time, d_expired_time, d_end_time, s_token) FROM '$$PATH$$/3290.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: adm_user; Owner: -
--

COPY adm_user.users (id, s_name, s_caption, d_registered, d_closed, b_active, id_contractor) FROM stdin;
\.
COPY adm_user.users (id, s_name, s_caption, d_registered, d_closed, b_active, id_contractor) FROM '$$PATH$$/3277.dat';

--
-- Data for Name: component; Type: TABLE DATA; Schema: uni_component; Owner: -
--

COPY uni_component.component (id, s_name, s_caption, s_description, id_parent) FROM stdin;
\.
COPY uni_component.component (id, s_name, s_caption, s_description, id_parent) FROM '$$PATH$$/3278.dat';

--
-- Data for Name: error; Type: TABLE DATA; Schema: uni_error; Owner: -
--

COPY uni_error.error (id, s_name, s_caption, s_description, d_created, d_edited, id_component) FROM stdin;
\.
COPY uni_error.error (id, s_name, s_caption, s_description, d_created, d_edited, id_component) FROM '$$PATH$$/3279.dat';

--
-- Name: seq_privelegy; Type: SEQUENCE SET; Schema: adm_privelegy; Owner: -
--

SELECT pg_catalog.setval('adm_privelegy.seq_privelegy', 1, false);


--
-- Name: seq_role_privs; Type: SEQUENCE SET; Schema: adm_role; Owner: -
--

SELECT pg_catalog.setval('adm_role.seq_role_privs', 1, false);


--
-- Name: seq_role_relation; Type: SEQUENCE SET; Schema: adm_role; Owner: -
--

SELECT pg_catalog.setval('adm_role.seq_role_relation', 2, true);


--
-- Name: seq_roles; Type: SEQUENCE SET; Schema: adm_role; Owner: -
--

SELECT pg_catalog.setval('adm_role.seq_roles', 5, true);


--
-- Name: seq_user_role; Type: SEQUENCE SET; Schema: adm_user; Owner: -
--

SELECT pg_catalog.setval('adm_user.seq_user_role', 21, true);


--
-- Name: seq_users; Type: SEQUENCE SET; Schema: adm_user; Owner: -
--

SELECT pg_catalog.setval('adm_user.seq_users', 23, true);


--
-- Name: seq_component; Type: SEQUENCE SET; Schema: uni_component; Owner: -
--

SELECT pg_catalog.setval('uni_component.seq_component', 9, true);


--
-- Name: seq_error; Type: SEQUENCE SET; Schema: uni_error; Owner: -
--

SELECT pg_catalog.setval('uni_error.seq_error', 23, true);


--
-- Name: udx_role_privs_id_role_id_privelegy; Type: INDEX; Schema: adm_role; Owner: -
--

CREATE UNIQUE INDEX udx_role_privs_id_role_id_privelegy ON adm_role.role_privs USING btree (id_role, id_privelegy);


--
-- Name: udx_user_role_uniq; Type: INDEX; Schema: adm_user; Owner: -
--

CREATE UNIQUE INDEX udx_user_role_uniq ON adm_user.user_role USING btree (id_user, id_role, b_active);


--
-- Name: udx_user_session_id_user_session; Type: INDEX; Schema: adm_user; Owner: -
--

CREATE UNIQUE INDEX udx_user_session_id_user_session ON adm_user.user_session USING btree (id_user, s_session_key);


--
-- Name: udx_user_session_id_user_session_token; Type: INDEX; Schema: adm_user; Owner: -
--

CREATE UNIQUE INDEX udx_user_session_id_user_session_token ON adm_user.user_session USING btree (id_user, s_session_key, s_token);


--
-- Name: privelegy pk_privelegy; Type: CONSTRAINT; Schema: adm_privelegy; Owner: -
--

ALTER TABLE ONLY adm_privelegy.privelegy
    ADD CONSTRAINT pk_privelegy PRIMARY KEY (id);


--
-- Name: role_privs pk_role_privs; Type: CONSTRAINT; Schema: adm_role; Owner: -
--

ALTER TABLE ONLY adm_role.role_privs
    ADD CONSTRAINT pk_role_privs PRIMARY KEY (id);


--
-- Name: role_relation pk_role_relation; Type: CONSTRAINT; Schema: adm_role; Owner: -
--

ALTER TABLE ONLY adm_role.role_relation
    ADD CONSTRAINT pk_role_relation PRIMARY KEY (id);


--
-- Name: roles pk_roles; Type: CONSTRAINT; Schema: adm_role; Owner: -
--

ALTER TABLE ONLY adm_role.roles
    ADD CONSTRAINT pk_roles PRIMARY KEY (id);


--
-- Name: user_role pk_user_role; Type: CONSTRAINT; Schema: adm_user; Owner: -
--

ALTER TABLE ONLY adm_user.user_role
    ADD CONSTRAINT pk_user_role PRIMARY KEY (id);


--
-- Name: user_session pk_user_session; Type: CONSTRAINT; Schema: adm_user; Owner: -
--

ALTER TABLE ONLY adm_user.user_session
    ADD CONSTRAINT pk_user_session PRIMARY KEY (id);


--
-- Name: users pk_users; Type: CONSTRAINT; Schema: adm_user; Owner: -
--

ALTER TABLE ONLY adm_user.users
    ADD CONSTRAINT pk_users PRIMARY KEY (id);


--
-- Name: component pk_component_id; Type: CONSTRAINT; Schema: uni_component; Owner: -
--

ALTER TABLE ONLY uni_component.component
    ADD CONSTRAINT pk_component_id PRIMARY KEY (id);


--
-- Name: error pk_defaulterror; Type: CONSTRAINT; Schema: uni_error; Owner: -
--

ALTER TABLE ONLY uni_error.error
    ADD CONSTRAINT pk_defaulterror PRIMARY KEY (id);


--
-- Name: udx_privelegy_s_name; Type: INDEX; Schema: adm_privelegy; Owner: -
--

CREATE UNIQUE INDEX udx_privelegy_s_name ON adm_privelegy.privelegy USING btree (s_name);


--
-- Name: idx_role_privs_id_privelegy; Type: INDEX; Schema: adm_role; Owner: -
--

CREATE INDEX idx_role_privs_id_privelegy ON adm_role.role_privs USING btree (id_privelegy);


--
-- Name: idx_role_privs_id_role; Type: INDEX; Schema: adm_role; Owner: -
--

CREATE INDEX idx_role_privs_id_role ON adm_role.role_privs USING btree (id_role);


--
-- Name: idx_role_relation_child; Type: INDEX; Schema: adm_role; Owner: -
--

CREATE INDEX idx_role_relation_child ON adm_role.role_relation USING btree (id_child_role);


--
-- Name: idx_role_relation_parent; Type: INDEX; Schema: adm_role; Owner: -
--

CREATE INDEX idx_role_relation_parent ON adm_role.role_relation USING btree (id_parent_role);


--
-- Name: idx_user_role_role; Type: INDEX; Schema: adm_user; Owner: -
--

CREATE INDEX idx_user_role_role ON adm_user.user_role USING btree (id_role);


--
-- Name: idx_user_role_user; Type: INDEX; Schema: adm_user; Owner: -
--

CREATE INDEX idx_user_role_user ON adm_user.user_role USING btree (id_user);


--
-- Name: idx_user_session_id_user; Type: INDEX; Schema: adm_user; Owner: -
--

CREATE INDEX idx_user_session_id_user ON adm_user.user_session USING btree (id_user);


--
-- Name: idx_users_contractor; Type: INDEX; Schema: adm_user; Owner: -
--

CREATE INDEX idx_users_contractor ON adm_user.users USING btree (id_contractor);


--
-- Name: idx_component_component_parent; Type: INDEX; Schema: uni_component; Owner: -
--

CREATE INDEX idx_component_component_parent ON uni_component.component USING btree (id_parent);


--
-- Name: idx_component_sname; Type: INDEX; Schema: uni_component; Owner: -
--

CREATE UNIQUE INDEX idx_component_sname ON uni_component.component USING btree (s_name);


--
-- Name: error_id_component_idx; Type: INDEX; Schema: uni_error; Owner: -
--

CREATE INDEX error_id_component_idx ON uni_error.error USING btree (id_component);


--
-- Name: idx_defaulterror_unq_name; Type: INDEX; Schema: uni_error; Owner: -
--

CREATE UNIQUE INDEX idx_defaulterror_unq_name ON uni_error.error USING btree (s_name);


--
-- Name: role_privs fk_role_privs_id_privelegy; Type: FK CONSTRAINT; Schema: adm_role; Owner: -
--

ALTER TABLE ONLY adm_role.role_privs
    ADD CONSTRAINT fk_role_privs_id_privelegy FOREIGN KEY (id_privelegy) REFERENCES adm_privelegy.privelegy(id);


--
-- Name: role_privs fk_role_privs_id_role; Type: FK CONSTRAINT; Schema: adm_role; Owner: -
--

ALTER TABLE ONLY adm_role.role_privs
    ADD CONSTRAINT fk_role_privs_id_role FOREIGN KEY (id_role) REFERENCES adm_role.roles(id);


--
-- Name: role_relation fk_role_relation_child; Type: FK CONSTRAINT; Schema: adm_role; Owner: -
--

ALTER TABLE ONLY adm_role.role_relation
    ADD CONSTRAINT fk_role_relation_child FOREIGN KEY (id_child_role) REFERENCES adm_role.roles(id) ON DELETE CASCADE;


--
-- Name: role_relation fk_role_relation_parent; Type: FK CONSTRAINT; Schema: adm_role; Owner: -
--

ALTER TABLE ONLY adm_role.role_relation
    ADD CONSTRAINT fk_role_relation_parent FOREIGN KEY (id_parent_role) REFERENCES adm_role.roles(id) ON DELETE CASCADE;


--
-- Name: user_role fk_user_role_role; Type: FK CONSTRAINT; Schema: adm_user; Owner: -
--

ALTER TABLE ONLY adm_user.user_role
    ADD CONSTRAINT fk_user_role_role FOREIGN KEY (id_role) REFERENCES adm_role.roles(id) ON DELETE CASCADE;


--
-- Name: user_role fk_user_role_user; Type: FK CONSTRAINT; Schema: adm_user; Owner: -
--

ALTER TABLE ONLY adm_user.user_role
    ADD CONSTRAINT fk_user_role_user FOREIGN KEY (id_user) REFERENCES adm_user.users(id) ON DELETE CASCADE;


--
-- Name: user_session fk_user_session_id_user; Type: FK CONSTRAINT; Schema: adm_user; Owner: -
--

ALTER TABLE ONLY adm_user.user_session
    ADD CONSTRAINT fk_user_session_id_user FOREIGN KEY (id_user) REFERENCES adm_user.users(id);


--
-- Name: component fk_component_component_parent; Type: FK CONSTRAINT; Schema: uni_component; Owner: -
--

ALTER TABLE ONLY uni_component.component
    ADD CONSTRAINT fk_component_component_parent FOREIGN KEY (id_parent) REFERENCES uni_component.component(id) ON DELETE CASCADE;


--
-- Name: error error_component_fk; Type: FK CONSTRAINT; Schema: uni_error; Owner: -
--

ALTER TABLE ONLY uni_error.error
    ADD CONSTRAINT error_component_fk FOREIGN KEY (id_component) REFERENCES uni_component.component(id) ON DELETE CASCADE;


--
-- Name: SCHEMA adm_privelegy; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA adm_privelegy TO uni_admin;
GRANT USAGE ON SCHEMA adm_privelegy TO uni_user;


--
-- Name: SCHEMA adm_role; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA adm_role TO uni_admin;
GRANT USAGE ON SCHEMA adm_role TO uni_user;


--
-- Name: SCHEMA adm_user; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA adm_user TO uni_admin;
GRANT USAGE ON SCHEMA adm_user TO uni_user;


--
-- Name: SCHEMA uni_api; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA uni_api TO uni_admin;
GRANT USAGE ON SCHEMA uni_api TO uni_user;


--
-- Name: SCHEMA uni_component; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA uni_component TO uni_admin;
GRANT USAGE ON SCHEMA uni_component TO uni_user;


--
-- Name: SCHEMA uni_const; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA uni_const TO uni_admin;
GRANT USAGE ON SCHEMA uni_const TO uni_user;


--
-- Name: SCHEMA uni_error; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA uni_error TO uni_admin;
GRANT USAGE ON SCHEMA uni_error TO uni_user;


--
-- Name: SCHEMA uni_generator; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA uni_generator TO uni_admin;
GRANT USAGE ON SCHEMA uni_generator TO uni_user;


--
-- Name: FUNCTION privelegy__after_edit(idp_self public.t_id); Type: ACL; Schema: adm_privelegy; Owner: -
--

GRANT ALL ON FUNCTION adm_privelegy.privelegy__after_edit(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION privelegy__delete_record(idp_self public.t_id); Type: ACL; Schema: adm_privelegy; Owner: -
--

GRANT ALL ON FUNCTION adm_privelegy.privelegy__delete_record(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION privelegy__find_by_name(sp_name public.t_name); Type: ACL; Schema: adm_privelegy; Owner: -
--

GRANT ALL ON FUNCTION adm_privelegy.privelegy__find_by_name(sp_name public.t_name) TO uni_user;


--
-- Name: TABLE privelegy; Type: ACL; Schema: adm_privelegy; Owner: -
--

GRANT SELECT ON TABLE adm_privelegy.privelegy TO uni_user;
GRANT ALL ON TABLE adm_privelegy.privelegy TO uni_admin;


--
-- Name: FUNCTION privelegy__get_row(idp_self public.t_id); Type: ACL; Schema: adm_privelegy; Owner: -
--

GRANT ALL ON FUNCTION adm_privelegy.privelegy__get_row(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION privelegy__insert_record(sp_name public.t_name, dp_begin public.t_date); Type: ACL; Schema: adm_privelegy; Owner: -
--

GRANT ALL ON FUNCTION adm_privelegy.privelegy__insert_record(sp_name public.t_name, dp_begin public.t_date) TO uni_user;


--
-- Name: FUNCTION privelegy__lock_record(idp_self public.t_id); Type: ACL; Schema: adm_privelegy; Owner: -
--

GRANT ALL ON FUNCTION adm_privelegy.privelegy__lock_record(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION privelegy__set_begin(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean); Type: ACL; Schema: adm_privelegy; Owner: -
--

GRANT ALL ON FUNCTION adm_privelegy.privelegy__set_begin(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION privelegy__set_caption(idp_self public.t_id, p_value public.t_caption, bp_internal_call public.t_boolean); Type: ACL; Schema: adm_privelegy; Owner: -
--

GRANT ALL ON FUNCTION adm_privelegy.privelegy__set_caption(idp_self public.t_id, p_value public.t_caption, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION privelegy__set_end(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean); Type: ACL; Schema: adm_privelegy; Owner: -
--

GRANT ALL ON FUNCTION adm_privelegy.privelegy__set_end(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION privelegy__set_name(idp_self public.t_id, p_value public.t_name, bp_internal_call public.t_boolean); Type: ACL; Schema: adm_privelegy; Owner: -
--

GRANT ALL ON FUNCTION adm_privelegy.privelegy__set_name(idp_self public.t_id, p_value public.t_name, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION privelegy__validate(idp_self public.t_id); Type: ACL; Schema: adm_privelegy; Owner: -
--

GRANT ALL ON FUNCTION adm_privelegy.privelegy__validate(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION role_privs__after_edit(idp_self public.t_id); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.role_privs__after_edit(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION role_privs__delete_record(idp_self public.t_id); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.role_privs__delete_record(idp_self public.t_id) TO uni_user;


--
-- Name: TABLE role_privs; Type: ACL; Schema: adm_role; Owner: -
--

GRANT SELECT ON TABLE adm_role.role_privs TO uni_user;
GRANT ALL ON TABLE adm_role.role_privs TO uni_admin;


--
-- Name: FUNCTION role_privs__get_row(idp_self public.t_id); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.role_privs__get_row(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION role_privs__insert_record(idp_role public.t_id, idp_privelegy public.t_id, dp_begin public.t_date); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.role_privs__insert_record(idp_role public.t_id, idp_privelegy public.t_id, dp_begin public.t_date) TO uni_user;


--
-- Name: FUNCTION role_privs__lock_record(idp_self public.t_id); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.role_privs__lock_record(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION role_privs__set_begin(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.role_privs__set_begin(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION role_privs__set_end(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.role_privs__set_end(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION role_privs__set_privelegy(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.role_privs__set_privelegy(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION role_privs__set_role(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.role_privs__set_role(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION role_privs__validate(idp_self public.t_id); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.role_privs__validate(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION role_relation__after_edit(idp_self public.t_id); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.role_relation__after_edit(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION role_relation__delete_record(idp_self public.t_id); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.role_relation__delete_record(idp_self public.t_id) TO uni_user;


--
-- Name: TABLE role_relation; Type: ACL; Schema: adm_role; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE adm_role.role_relation TO uni_admin;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE adm_role.role_relation TO uni_user;


--
-- Name: FUNCTION role_relation__get_row(idp_self public.t_id); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.role_relation__get_row(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION role_relation__insert_record(idp_parent_role public.t_id, idp_child_role public.t_id); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.role_relation__insert_record(idp_parent_role public.t_id, idp_child_role public.t_id) TO uni_user;


--
-- Name: FUNCTION role_relation__lock_record(idp_self public.t_id); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.role_relation__lock_record(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION role_relation__set_active(idp_self public.t_id, p_value public.t_boolean, bp_internal_call public.t_boolean); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.role_relation__set_active(idp_self public.t_id, p_value public.t_boolean, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION role_relation__set_begin(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.role_relation__set_begin(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION role_relation__set_child_role(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.role_relation__set_child_role(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION role_relation__set_end(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.role_relation__set_end(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION role_relation__set_parent_role(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.role_relation__set_parent_role(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION role_relation__validate(idp_self public.t_id); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.role_relation__validate(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION roles__after_edit(idp_self public.t_id); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.roles__after_edit(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION roles__delete_record(idp_self public.t_id); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.roles__delete_record(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION roles__find_by_name(sp_name public.t_name); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.roles__find_by_name(sp_name public.t_name) TO uni_user;


--
-- Name: TABLE roles; Type: ACL; Schema: adm_role; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE adm_role.roles TO uni_admin;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE adm_role.roles TO uni_user;


--
-- Name: FUNCTION roles__get_row(idp_self public.t_id); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.roles__get_row(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION roles__insert_record(); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.roles__insert_record() TO uni_user;


--
-- Name: FUNCTION roles__lock_record(idp_self public.t_id); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.roles__lock_record(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION roles__set_active(idp_self public.t_id, p_value public.t_boolean); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.roles__set_active(idp_self public.t_id, p_value public.t_boolean) TO uni_user;


--
-- Name: FUNCTION roles__set_begin(idp_self public.t_id, p_value public.t_date); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.roles__set_begin(idp_self public.t_id, p_value public.t_date) TO uni_user;


--
-- Name: FUNCTION roles__set_caption(idp_self public.t_id, p_value public.t_caption); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.roles__set_caption(idp_self public.t_id, p_value public.t_caption) TO uni_user;


--
-- Name: FUNCTION roles__set_end(idp_self public.t_id, p_value public.t_date); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.roles__set_end(idp_self public.t_id, p_value public.t_date) TO uni_user;


--
-- Name: FUNCTION roles__set_name(idp_self public.t_id, p_value public.t_name); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.roles__set_name(idp_self public.t_id, p_value public.t_name) TO uni_user;


--
-- Name: FUNCTION roles__validate(idp_self public.t_id); Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON FUNCTION adm_role.roles__validate(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION user_role__after_edit(idp_self public.t_id); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_role__after_edit(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION user_role__delete_record(idp_self public.t_id); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_role__delete_record(idp_self public.t_id) TO uni_user;


--
-- Name: TABLE user_role; Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON TABLE adm_user.user_role TO uni_admin;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE adm_user.user_role TO uni_user;


--
-- Name: FUNCTION user_role__get_row(idp_self public.t_id); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_role__get_row(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION user_role__insert_record(idp_user public.t_id, idp_role public.t_id); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_role__insert_record(idp_user public.t_id, idp_role public.t_id) TO uni_user;


--
-- Name: FUNCTION user_role__lock_record(idp_self public.t_id); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_role__lock_record(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION user_role__set_active(idp_self public.t_id, p_value public.t_boolean); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_role__set_active(idp_self public.t_id, p_value public.t_boolean) TO uni_user;


--
-- Name: FUNCTION user_role__set_begin(idp_self public.t_id, p_value public.t_date); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_role__set_begin(idp_self public.t_id, p_value public.t_date) TO uni_user;


--
-- Name: FUNCTION user_role__set_end(idp_self public.t_id, p_value public.t_date); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_role__set_end(idp_self public.t_id, p_value public.t_date) TO uni_user;


--
-- Name: FUNCTION user_role__set_role(idp_self public.t_id, p_value public.t_id); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_role__set_role(idp_self public.t_id, p_value public.t_id) TO uni_user;


--
-- Name: FUNCTION user_role__set_user(idp_self public.t_id, p_value public.t_id); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_role__set_user(idp_self public.t_id, p_value public.t_id) TO uni_user;


--
-- Name: FUNCTION user_role__validate(idp_self public.t_id); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_role__validate(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION user_session__after_edit(idp_self public.t_id); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_session__after_edit(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION user_session__delete_record(idp_self public.t_id); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_session__delete_record(idp_self public.t_id) TO uni_user;


--
-- Name: TABLE user_session; Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON TABLE adm_user.user_session TO uni_admin;
GRANT SELECT,INSERT,UPDATE ON TABLE adm_user.user_session TO uni_user;


--
-- Name: FUNCTION user_session__get_row(idp_self public.t_id); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_session__get_row(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION user_session__insert_record(idp_user public.t_id, sp_session_key public.t_shortstring, dp_begin_time public.t_datetime, dp_expired_time public.t_datetime); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_session__insert_record(idp_user public.t_id, sp_session_key public.t_shortstring, dp_begin_time public.t_datetime, dp_expired_time public.t_datetime) TO uni_user;


--
-- Name: FUNCTION user_session__lock_record(idp_self public.t_id); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_session__lock_record(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION user_session__set_begin_time(idp_self public.t_id, p_value public.t_datetime, bp_internal_call public.t_boolean); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_session__set_begin_time(idp_self public.t_id, p_value public.t_datetime, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION user_session__set_end_time(idp_self public.t_id, p_value public.t_datetime, bp_internal_call public.t_boolean); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_session__set_end_time(idp_self public.t_id, p_value public.t_datetime, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION user_session__set_expired_time(idp_self public.t_id, p_value public.t_datetime, bp_internal_call public.t_boolean); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_session__set_expired_time(idp_self public.t_id, p_value public.t_datetime, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION user_session__set_session_key(idp_self public.t_id, p_value public.t_shortstring, bp_internal_call public.t_boolean); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_session__set_session_key(idp_self public.t_id, p_value public.t_shortstring, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION user_session__set_token(idp_self public.t_id, p_value public.t_shortstring, bp_internal_call public.t_boolean); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_session__set_token(idp_self public.t_id, p_value public.t_shortstring, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION user_session__set_user(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_session__set_user(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION user_session__validate(idp_self public.t_id); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.user_session__validate(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION users__create_db_user(idp_self public.t_id, sp_password public.t_shortstring); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.users__create_db_user(idp_self public.t_id, sp_password public.t_shortstring) TO uni_admin;
GRANT ALL ON FUNCTION adm_user.users__create_db_user(idp_self public.t_id, sp_password public.t_shortstring) TO uni_user;


--
-- Name: FUNCTION users__get_person(sp_name public.t_name); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.users__get_person(sp_name public.t_name) TO uni_user;


--
-- Name: TABLE users; Type: ACL; Schema: adm_user; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE adm_user.users TO uni_admin;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE adm_user.users TO uni_user;


--
-- Name: FUNCTION users__register_new_user(sp_user_name public.t_name, sp_user_caption public.t_caption, sp_password public.t_shortstring); Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON FUNCTION adm_user.users__register_new_user(sp_user_name public.t_name, sp_user_caption public.t_caption, sp_password public.t_shortstring) TO uni_admin;
GRANT ALL ON FUNCTION adm_user.users__register_new_user(sp_user_name public.t_name, sp_user_caption public.t_caption, sp_password public.t_shortstring) TO uni_user;


--
-- Name: FUNCTION get_table_id(sp_schema public.t_name, sp_table public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.get_table_id(sp_schema public.t_name, sp_table public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.get_table_id(sp_schema public.t_name, sp_table public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_boolean, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_boolean, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_boolean, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_caption, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_caption, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_caption, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_clob, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_clob, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_clob, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_code, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_code, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_code, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_date, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_date, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_date, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_float, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_float, sp_identityfield public.t_name) TO uni_user;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_html, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_html, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_html, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_id, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_id, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_id, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_integer, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_integer, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_integer, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_json, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_json, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_json, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_longstring, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_longstring, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_longstring, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_money, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_money, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_money, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_name, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_name, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_name, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_shortstring, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_shortstring, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_shortstring, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_xml, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_xml, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_xml, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION component__after_edit(idp_self public.t_id); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__after_edit(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__after_edit(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION component__delete_record(idp_self public.t_id); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__delete_record(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__delete_record(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION component__find_by_name(sp_name public.t_name); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__find_by_name(sp_name public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__find_by_name(sp_name public.t_name) TO uni_admin;


--
-- Name: TABLE component; Type: ACL; Schema: uni_component; Owner: -
--

GRANT SELECT ON TABLE uni_component.component TO uni_user;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE uni_component.component TO uni_admin;


--
-- Name: FUNCTION component__get_row(idp_self public.t_id); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__get_row(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__get_row(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION component__insert_record(sp_name public.t_name); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__insert_record(sp_name public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__insert_record(sp_name public.t_name) TO uni_admin;


--
-- Name: FUNCTION component__lock_record(idp_self public.t_id); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__lock_record(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__lock_record(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION component__set_caption(idp_self public.t_id, p_value public.t_caption); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__set_caption(idp_self public.t_id, p_value public.t_caption) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__set_caption(idp_self public.t_id, p_value public.t_caption) TO uni_admin;


--
-- Name: FUNCTION component__set_description(idp_self public.t_id, p_value public.t_description); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__set_description(idp_self public.t_id, p_value public.t_description) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__set_description(idp_self public.t_id, p_value public.t_description) TO uni_admin;


--
-- Name: FUNCTION component__set_name(idp_self public.t_id, p_value public.t_name); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__set_name(idp_self public.t_id, p_value public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__set_name(idp_self public.t_id, p_value public.t_name) TO uni_admin;


--
-- Name: FUNCTION component__set_parent(idp_self public.t_id, p_value public.t_id); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__set_parent(idp_self public.t_id, p_value public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__set_parent(idp_self public.t_id, p_value public.t_id) TO uni_admin;


--
-- Name: FUNCTION component__validate(idp_self public.t_id); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__validate(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__validate(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION endl(); Type: ACL; Schema: uni_const; Owner: -
--

GRANT ALL ON FUNCTION uni_const.endl() TO uni_user;
GRANT ALL ON FUNCTION uni_const.endl() TO uni_admin;


--
-- Name: FUNCTION max_date(); Type: ACL; Schema: uni_const; Owner: -
--

GRANT ALL ON FUNCTION uni_const.max_date() TO uni_user;


--
-- Name: FUNCTION min_date(); Type: ACL; Schema: uni_const; Owner: -
--

GRANT ALL ON FUNCTION uni_const.min_date() TO uni_user;


--
-- Name: FUNCTION reg_col_type(); Type: ACL; Schema: uni_const; Owner: -
--

GRANT ALL ON FUNCTION uni_const.reg_col_type() TO uni_admin;
GRANT ALL ON FUNCTION uni_const.reg_col_type() TO uni_user;


--
-- Name: FUNCTION reg_replace(sp_prefix public.t_name); Type: ACL; Schema: uni_const; Owner: -
--

GRANT ALL ON FUNCTION uni_const.reg_replace(sp_prefix public.t_name) TO uni_admin;
GRANT ALL ON FUNCTION uni_const.reg_replace(sp_prefix public.t_name) TO uni_user;


--
-- Name: FUNCTION error__after_edit(idp_self public.t_id); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__after_edit(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__after_edit(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION error__delete_record(idp_self public.t_id); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__delete_record(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__delete_record(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION error__find_by_name(sp_name public.t_name); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__find_by_name(sp_name public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__find_by_name(sp_name public.t_name) TO uni_admin;


--
-- Name: TABLE error; Type: ACL; Schema: uni_error; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE uni_error.error TO uni_admin;
GRANT SELECT ON TABLE uni_error.error TO uni_user;


--
-- Name: FUNCTION error__get_row(idp_self public.t_id); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__get_row(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__get_row(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION error__insert_record(sp_name public.t_name, idp_component public.t_id); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__insert_record(sp_name public.t_name, idp_component public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__insert_record(sp_name public.t_name, idp_component public.t_id) TO uni_admin;


--
-- Name: FUNCTION error__lock_record(idp_self public.t_id); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__lock_record(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__lock_record(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION error__set_caption(idp_self public.t_id, p_value public.t_caption); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__set_caption(idp_self public.t_id, p_value public.t_caption) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__set_caption(idp_self public.t_id, p_value public.t_caption) TO uni_admin;


--
-- Name: FUNCTION error__set_component(idp_self public.t_id, p_value public.t_id); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__set_component(idp_self public.t_id, p_value public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__set_component(idp_self public.t_id, p_value public.t_id) TO uni_admin;


--
-- Name: FUNCTION error__set_created(idp_self public.t_id, p_value public.t_datetime); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__set_created(idp_self public.t_id, p_value public.t_datetime) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__set_created(idp_self public.t_id, p_value public.t_datetime) TO uni_admin;


--
-- Name: FUNCTION error__set_description(idp_self public.t_id, p_value public.t_description); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__set_description(idp_self public.t_id, p_value public.t_description) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__set_description(idp_self public.t_id, p_value public.t_description) TO uni_admin;


--
-- Name: FUNCTION error__set_edited(idp_self public.t_id, p_value public.t_datetime); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__set_edited(idp_self public.t_id, p_value public.t_datetime) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__set_edited(idp_self public.t_id, p_value public.t_datetime) TO uni_admin;


--
-- Name: FUNCTION error__set_name(idp_self public.t_id, p_value public.t_name); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__set_name(idp_self public.t_id, p_value public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__set_name(idp_self public.t_id, p_value public.t_name) TO uni_admin;


--
-- Name: FUNCTION error__validate(idp_self public.t_id); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__validate(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__validate(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION generate(sp_component public.t_name, sp_name public.t_name, VARIADIC params public.t_shortstring[]); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.generate(sp_component public.t_name, sp_name public.t_name, VARIADIC params public.t_shortstring[]) TO uni_user;
GRANT ALL ON FUNCTION uni_error.generate(sp_component public.t_name, sp_name public.t_name, VARIADIC params public.t_shortstring[]) TO uni_admin;


--
-- Name: FUNCTION generate_after_edit(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_after_edit(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_after_edit(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_delete_record(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_delete_record(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_delete_record(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_find_by_code(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_find_by_code(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_find_by_code(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_find_by_name(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_find_by_name(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;
GRANT ALL ON FUNCTION uni_generator.generate_find_by_name(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;


--
-- Name: FUNCTION generate_get_row(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_get_row(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_get_row(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_grants(sp_schemaname public.t_name, sp_tablename public.t_name, sap_roles public.t_shortstringarray); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_grants(sp_schemaname public.t_name, sp_tablename public.t_name, sap_roles public.t_shortstringarray) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_grants(sp_schemaname public.t_name, sp_tablename public.t_name, sap_roles public.t_shortstringarray) TO uni_admin;


--
-- Name: FUNCTION generate_insert_record(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_insert_record(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_insert_record(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_lock_record(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_lock_record(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_lock_record(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_setters(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_setters(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_setters(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_table_api(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_table_api(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_table_api(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_validate(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_validate(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_validate(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: SEQUENCE seq_role_relation; Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON SEQUENCE adm_role.seq_role_relation TO uni_admin;
GRANT ALL ON SEQUENCE adm_role.seq_role_relation TO uni_user;


--
-- Name: SEQUENCE seq_roles; Type: ACL; Schema: adm_role; Owner: -
--

GRANT ALL ON SEQUENCE adm_role.seq_roles TO uni_admin;
GRANT ALL ON SEQUENCE adm_role.seq_roles TO uni_user;


--
-- Name: SEQUENCE seq_user_role; Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON SEQUENCE adm_user.seq_user_role TO uni_admin;
GRANT ALL ON SEQUENCE adm_user.seq_user_role TO uni_user;


--
-- Name: SEQUENCE seq_users; Type: ACL; Schema: adm_user; Owner: -
--

GRANT ALL ON SEQUENCE adm_user.seq_users TO uni_admin;
GRANT ALL ON SEQUENCE adm_user.seq_users TO uni_user;


--
-- Name: SEQUENCE seq_component; Type: ACL; Schema: uni_component; Owner: -
--

GRANT SELECT ON SEQUENCE uni_component.seq_component TO uni_user;


--
-- Name: TABLE component_errors; Type: ACL; Schema: uni_error; Owner: -
--

GRANT SELECT ON TABLE uni_error.component_errors TO uni_admin;
GRANT SELECT ON TABLE uni_error.component_errors TO uni_user;


--
-- PostgreSQL database dump complete
--

