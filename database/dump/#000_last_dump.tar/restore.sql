--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.11
-- Dumped by pg_dump version 12.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE square;
--
-- Name: square; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE square WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Russian_Russia.1251@icu' LC_CTYPE = 'Russian_Russia.1251';


\connect square

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: square; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA square;


--
-- Name: dblink; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS dblink WITH SCHEMA public;


--
-- Name: EXTENSION dblink; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION dblink IS 'connect to other PostgreSQL databases from within a database';


--
-- Name: t_boolean; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_boolean AS boolean;


--
-- Name: t_booleanarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_booleanarray AS boolean[];


--
-- Name: t_caption; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_caption AS character varying(254);


--
-- Name: t_captionarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_captionarray AS character varying(254)[];


--
-- Name: t_clob; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_clob AS text;


--
-- Name: t_code; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_code AS character varying(254);


--
-- Name: t_codearray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_codearray AS character varying(254)[];


--
-- Name: t_date; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_date AS date;


--
-- Name: t_datearray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_datearray AS date[];


--
-- Name: t_datetime; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_datetime AS timestamp without time zone;


--
-- Name: t_datetimearray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_datetimearray AS timestamp without time zone[];


--
-- Name: t_description; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_description AS character varying(4000);


--
-- Name: t_float; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_float AS numeric;


--
-- Name: t_html; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_html AS text;


--
-- Name: t_id; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_id AS numeric(15,0);


--
-- Name: t_idarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_idarray AS numeric(15,0)[];


--
-- Name: t_integer; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_integer AS bigint;


--
-- Name: t_integerarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_integerarray AS integer[];


--
-- Name: t_json; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_json AS jsonb;


--
-- Name: t_longstring; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_longstring AS character varying(4000);


--
-- Name: t_longstringarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_longstringarray AS character varying(4000)[];


--
-- Name: t_money; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_money AS numeric(15,4);


--
-- Name: t_moneyarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_moneyarray AS numeric(15,4)[];


--
-- Name: t_name; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_name AS character varying(30);


--
-- Name: t_namearray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_namearray AS character varying(30)[];


--
-- Name: t_shortstring; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_shortstring AS character varying(254);


--
-- Name: t_shortstringarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_shortstringarray AS character varying(254)[];


--
-- Name: t_stringarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_stringarray AS text[];


--
-- Name: t_xml; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_xml AS xml;


--
-- Name: seq_adm_group; Type: SEQUENCE; Schema: square; Owner: -
--

CREATE SEQUENCE square.seq_adm_group
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: adm_group; Type: TABLE; Schema: square; Owner: -
--

CREATE TABLE square.adm_group (
    id public.t_id DEFAULT nextval('square.seq_adm_group'::regclass) NOT NULL,
    name public.t_name DEFAULT ''::character varying NOT NULL,
    caption public.t_caption,
    description public.t_description
);


--
-- Name: TABLE adm_group; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON TABLE square.adm_group IS 'Группы доступа';


--
-- Name: COLUMN adm_group.id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_group.id IS 'ID';


--
-- Name: COLUMN adm_group.name; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_group.name IS 'Системное имя группы';


--
-- Name: COLUMN adm_group.caption; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_group.caption IS 'Наименование группы';


--
-- Name: COLUMN adm_group.description; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_group.description IS 'Описание';


--
-- Name: seq_adm_group_role; Type: SEQUENCE; Schema: square; Owner: -
--

CREATE SEQUENCE square.seq_adm_group_role
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: adm_group_role; Type: TABLE; Schema: square; Owner: -
--

CREATE TABLE square.adm_group_role (
    id public.t_id DEFAULT nextval('square.seq_adm_group_role'::regclass) NOT NULL,
    group_id public.t_id NOT NULL,
    role_id public.t_id NOT NULL
);


--
-- Name: TABLE adm_group_role; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON TABLE square.adm_group_role IS 'Роли в группах';


--
-- Name: COLUMN adm_group_role.id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_group_role.id IS 'ID';


--
-- Name: COLUMN adm_group_role.group_id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_group_role.group_id IS 'ID Группы';


--
-- Name: COLUMN adm_group_role.role_id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_group_role.role_id IS 'ID Роли';


--
-- Name: seq_adm_role; Type: SEQUENCE; Schema: square; Owner: -
--

CREATE SEQUENCE square.seq_adm_role
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: adm_role; Type: TABLE; Schema: square; Owner: -
--

CREATE TABLE square.adm_role (
    id public.t_id DEFAULT nextval('square.seq_adm_role'::regclass) NOT NULL,
    name public.t_name DEFAULT ''::character varying NOT NULL,
    caption public.t_caption,
    description public.t_description
);


--
-- Name: TABLE adm_role; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON TABLE square.adm_role IS 'Роли доступа';


--
-- Name: COLUMN adm_role.id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_role.id IS 'ID';


--
-- Name: COLUMN adm_role.name; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_role.name IS 'Системное имя роли';


--
-- Name: COLUMN adm_role.caption; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_role.caption IS 'Наименование роли';


--
-- Name: COLUMN adm_role.description; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_role.description IS 'Описание';


--
-- Name: seq_adm_role_menu_item; Type: SEQUENCE; Schema: square; Owner: -
--

CREATE SEQUENCE square.seq_adm_role_menu_item
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: adm_role_menu_item; Type: TABLE; Schema: square; Owner: -
--

CREATE TABLE square.adm_role_menu_item (
    id public.t_id DEFAULT nextval('square.seq_adm_role_menu_item'::regclass) NOT NULL,
    role_id public.t_id NOT NULL,
    menu_item_id public.t_id NOT NULL
);


--
-- Name: TABLE adm_role_menu_item; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON TABLE square.adm_role_menu_item IS 'Доступ роли к пунктам меню';


--
-- Name: COLUMN adm_role_menu_item.id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_role_menu_item.id IS 'ID';


--
-- Name: COLUMN adm_role_menu_item.role_id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_role_menu_item.role_id IS 'ID Роли';


--
-- Name: COLUMN adm_role_menu_item.menu_item_id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_role_menu_item.menu_item_id IS 'ID Пункта меню';


--
-- Name: seq_adm_user; Type: SEQUENCE; Schema: square; Owner: -
--

CREATE SEQUENCE square.seq_adm_user
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: adm_user; Type: TABLE; Schema: square; Owner: -
--

CREATE TABLE square.adm_user (
    id public.t_id DEFAULT nextval('square.seq_adm_user'::regclass) NOT NULL,
    name public.t_name DEFAULT ''::character varying NOT NULL,
    caption public.t_caption,
    hash public.t_shortstring,
    person_id public.t_id
);


--
-- Name: TABLE adm_user; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON TABLE square.adm_user IS 'Пользователи площадки';


--
-- Name: COLUMN adm_user.id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_user.id IS 'ID';


--
-- Name: COLUMN adm_user.name; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_user.name IS 'Системное имя пользователя (email)';


--
-- Name: COLUMN adm_user.caption; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_user.caption IS 'Наименование (ФИО/Название организации)';


--
-- Name: COLUMN adm_user.hash; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_user.hash IS 'Хэщ пароля';


--
-- Name: COLUMN adm_user.person_id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_user.person_id IS 'ID Физ. лица';


--
-- Name: seq_adm_user_group; Type: SEQUENCE; Schema: square; Owner: -
--

CREATE SEQUENCE square.seq_adm_user_group
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: adm_user_group; Type: TABLE; Schema: square; Owner: -
--

CREATE TABLE square.adm_user_group (
    id public.t_id DEFAULT nextval('square.seq_adm_user_group'::regclass) NOT NULL,
    user_id public.t_id NOT NULL,
    group_id public.t_id NOT NULL
);


--
-- Name: TABLE adm_user_group; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON TABLE square.adm_user_group IS 'Группы пользователя';


--
-- Name: COLUMN adm_user_group.id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_user_group.id IS 'ID';


--
-- Name: COLUMN adm_user_group.user_id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_user_group.user_id IS 'ID Пользователя';


--
-- Name: COLUMN adm_user_group.group_id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.adm_user_group.group_id IS 'ID Группы';


--
-- Name: seq_krn_menu_group; Type: SEQUENCE; Schema: square; Owner: -
--

CREATE SEQUENCE square.seq_krn_menu_group
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: krn_menu_group; Type: TABLE; Schema: square; Owner: -
--

CREATE TABLE square.krn_menu_group (
    id public.t_id DEFAULT nextval('square.seq_krn_menu_group'::regclass) NOT NULL,
    title public.t_shortstring,
    icon public.t_shortstring
);


--
-- Name: TABLE krn_menu_group; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON TABLE square.krn_menu_group IS 'Группы пунктов меню';


--
-- Name: COLUMN krn_menu_group.id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.krn_menu_group.id IS 'ID';


--
-- Name: COLUMN krn_menu_group.title; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.krn_menu_group.title IS 'Наименование группы';


--
-- Name: COLUMN krn_menu_group.icon; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.krn_menu_group.icon IS 'Иконка';


--
-- Name: seq_krn_menu_item; Type: SEQUENCE; Schema: square; Owner: -
--

CREATE SEQUENCE square.seq_krn_menu_item
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: krn_menu_item; Type: TABLE; Schema: square; Owner: -
--

CREATE TABLE square.krn_menu_item (
    id public.t_id DEFAULT nextval('square.seq_krn_menu_item'::regclass) NOT NULL,
    group_id public.t_id NOT NULL,
    title public.t_shortstring,
    url public.t_shortstring,
    icon public.t_shortstring
);


--
-- Name: TABLE krn_menu_item; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON TABLE square.krn_menu_item IS 'Пункты меню';


--
-- Name: COLUMN krn_menu_item.id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.krn_menu_item.id IS 'ID';


--
-- Name: COLUMN krn_menu_item.group_id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.krn_menu_item.group_id IS 'ID Группы (по-умолчанию в общией)';


--
-- Name: COLUMN krn_menu_item.title; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.krn_menu_item.title IS 'Наименование пункта меню';


--
-- Name: COLUMN krn_menu_item.url; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.krn_menu_item.url IS 'URL для перехода';


--
-- Name: COLUMN krn_menu_item.icon; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.krn_menu_item.icon IS 'Иконка пункта меню';


--
-- Name: seq_sqr_role; Type: SEQUENCE; Schema: square; Owner: -
--

CREATE SEQUENCE square.seq_sqr_role
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_sqr_square; Type: SEQUENCE; Schema: square; Owner: -
--

CREATE SEQUENCE square.seq_sqr_square
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_sqr_square_role; Type: SEQUENCE; Schema: square; Owner: -
--

CREATE SEQUENCE square.seq_sqr_square_role
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_sqr_square_team; Type: SEQUENCE; Schema: square; Owner: -
--

CREATE SEQUENCE square.seq_sqr_square_team
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_sqr_square_timer; Type: SEQUENCE; Schema: square; Owner: -
--

CREATE SEQUENCE square.seq_sqr_square_timer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_sqr_square_timer_detail; Type: SEQUENCE; Schema: square; Owner: -
--

CREATE SEQUENCE square.seq_sqr_square_timer_detail
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sqr_role; Type: TABLE; Schema: square; Owner: -
--

CREATE TABLE square.sqr_role (
    id public.t_id DEFAULT nextval('square.seq_sqr_role'::regclass) NOT NULL,
    name public.t_name DEFAULT ''::character varying NOT NULL,
    caption public.t_caption,
    description public.t_description,
    group_id public.t_id
);


--
-- Name: TABLE sqr_role; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON TABLE square.sqr_role IS 'Роли на площадке';


--
-- Name: COLUMN sqr_role.id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_role.id IS 'ID';


--
-- Name: COLUMN sqr_role.name; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_role.name IS 'Системное имя';


--
-- Name: COLUMN sqr_role.caption; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_role.caption IS 'Наименование';


--
-- Name: COLUMN sqr_role.description; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_role.description IS 'Описание';


--
-- Name: COLUMN sqr_role.group_id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_role.group_id IS 'ID Связанной группы доступа';


--
-- Name: sqr_square; Type: TABLE; Schema: square; Owner: -
--

CREATE TABLE square.sqr_square (
    id public.t_id DEFAULT nextval('square.seq_sqr_square'::regclass) NOT NULL,
    name public.t_name DEFAULT ''::character varying NOT NULL,
    caption public.t_caption,
    description public.t_description
);


--
-- Name: TABLE sqr_square; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON TABLE square.sqr_square IS 'Площадки';


--
-- Name: COLUMN sqr_square.id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square.id IS 'ID';


--
-- Name: COLUMN sqr_square.name; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square.name IS 'Системное имя';


--
-- Name: COLUMN sqr_square.caption; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square.caption IS 'Наименование';


--
-- Name: COLUMN sqr_square.description; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square.description IS 'Описание';


--
-- Name: sqr_square_team; Type: TABLE; Schema: square; Owner: -
--

CREATE TABLE square.sqr_square_team (
    id public.t_id DEFAULT nextval('square.seq_sqr_square_team'::regclass) NOT NULL,
    square_id public.t_id NOT NULL,
    name public.t_name DEFAULT ''::character varying NOT NULL,
    caption public.t_caption,
    description public.t_description
);


--
-- Name: TABLE sqr_square_team; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON TABLE square.sqr_square_team IS 'Команды на площадке';


--
-- Name: COLUMN sqr_square_team.id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_team.id IS 'ID';


--
-- Name: COLUMN sqr_square_team.square_id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_team.square_id IS 'ID Площадки';


--
-- Name: COLUMN sqr_square_team.name; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_team.name IS 'Системное имя';


--
-- Name: COLUMN sqr_square_team.caption; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_team.caption IS 'Наименование';


--
-- Name: COLUMN sqr_square_team.description; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_team.description IS 'Описание';


--
-- Name: sqr_square_timer; Type: TABLE; Schema: square; Owner: -
--

CREATE TABLE square.sqr_square_timer (
    id public.t_id DEFAULT nextval('square.seq_sqr_square_timer'::regclass) NOT NULL,
    square_id public.t_id NOT NULL,
    team_id public.t_id NOT NULL,
    caption public.t_caption,
    count public.t_integer DEFAULT 0,
    begin_time public.t_datetime,
    pause_time public.t_datetime,
    continue_time public.t_datetime,
    stop_time public.t_datetime,
    state public.t_shortstring DEFAULT 'READY'::character varying
);


--
-- Name: TABLE sqr_square_timer; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON TABLE square.sqr_square_timer IS 'Таймеры площалки';


--
-- Name: COLUMN sqr_square_timer.id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_timer.id IS 'ID';


--
-- Name: COLUMN sqr_square_timer.square_id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_timer.square_id IS 'ID Площадки';


--
-- Name: COLUMN sqr_square_timer.team_id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_timer.team_id IS 'ID Команды';


--
-- Name: COLUMN sqr_square_timer.caption; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_timer.caption IS 'Наименование таймера';


--
-- Name: COLUMN sqr_square_timer.count; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_timer.count IS 'Количество секунд';


--
-- Name: COLUMN sqr_square_timer.begin_time; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_timer.begin_time IS 'Дата/Время запуска таймера';


--
-- Name: COLUMN sqr_square_timer.pause_time; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_timer.pause_time IS 'Дата/Время последней приостановки таймера';


--
-- Name: COLUMN sqr_square_timer.continue_time; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_timer.continue_time IS 'Дата/Время последнего возобновления таймера';


--
-- Name: COLUMN sqr_square_timer.stop_time; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_timer.stop_time IS 'Дата/Время останова таймера';


--
-- Name: COLUMN sqr_square_timer.state; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_timer.state IS 'Состояние таймера (по-умолчанию READY)';


--
-- Name: sqr_square_timer_detail; Type: TABLE; Schema: square; Owner: -
--

CREATE TABLE square.sqr_square_timer_detail (
    id public.t_id DEFAULT nextval('square.seq_sqr_square_timer_detail'::regclass) NOT NULL,
    timer_id public.t_id NOT NULL,
    state public.t_shortstring,
    "time" public.t_datetime,
    count public.t_integer,
    description public.t_clob
);


--
-- Name: TABLE sqr_square_timer_detail; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON TABLE square.sqr_square_timer_detail IS 'Расширенная информация по таймерам команд';


--
-- Name: COLUMN sqr_square_timer_detail.id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_timer_detail.id IS 'ID';


--
-- Name: COLUMN sqr_square_timer_detail.timer_id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_timer_detail.timer_id IS 'ID Таймера';


--
-- Name: COLUMN sqr_square_timer_detail.state; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_timer_detail.state IS 'Состояние';


--
-- Name: COLUMN sqr_square_timer_detail."time"; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_timer_detail."time" IS 'Дата/Время перевода в состояние';


--
-- Name: COLUMN sqr_square_timer_detail.count; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_timer_detail.count IS 'Количество секунд в состоянии';


--
-- Name: COLUMN sqr_square_timer_detail.description; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_timer_detail.description IS 'Дополнительная информация';


--
-- Name: sqr_square_user; Type: TABLE; Schema: square; Owner: -
--

CREATE TABLE square.sqr_square_user (
    id public.t_id DEFAULT nextval('square.seq_sqr_square_role'::regclass) NOT NULL,
    square_id public.t_id NOT NULL,
    user_id public.t_id NOT NULL,
    role_id public.t_id NOT NULL,
    team_id public.t_id
);


--
-- Name: TABLE sqr_square_user; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON TABLE square.sqr_square_user IS 'Роли на площадке';


--
-- Name: COLUMN sqr_square_user.id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_user.id IS 'ID';


--
-- Name: COLUMN sqr_square_user.square_id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_user.square_id IS 'ID Площадки';


--
-- Name: COLUMN sqr_square_user.user_id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_user.user_id IS 'ID Пользователя';


--
-- Name: COLUMN sqr_square_user.role_id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_user.role_id IS 'ID Роли на площадке';


--
-- Name: COLUMN sqr_square_user.team_id; Type: COMMENT; Schema: square; Owner: -
--

COMMENT ON COLUMN square.sqr_square_user.team_id IS 'ID Команды';


--
-- Data for Name: adm_group; Type: TABLE DATA; Schema: square; Owner: -
--

COPY square.adm_group (id, name, caption, description) FROM stdin;
\.
COPY square.adm_group (id, name, caption, description) FROM '$$PATH$$/3200.dat';

--
-- Data for Name: adm_group_role; Type: TABLE DATA; Schema: square; Owner: -
--

COPY square.adm_group_role (id, group_id, role_id) FROM stdin;
\.
COPY square.adm_group_role (id, group_id, role_id) FROM '$$PATH$$/3202.dat';

--
-- Data for Name: adm_role; Type: TABLE DATA; Schema: square; Owner: -
--

COPY square.adm_role (id, name, caption, description) FROM stdin;
\.
COPY square.adm_role (id, name, caption, description) FROM '$$PATH$$/3201.dat';

--
-- Data for Name: adm_role_menu_item; Type: TABLE DATA; Schema: square; Owner: -
--

COPY square.adm_role_menu_item (id, role_id, menu_item_id) FROM stdin;
\.
COPY square.adm_role_menu_item (id, role_id, menu_item_id) FROM '$$PATH$$/3213.dat';

--
-- Data for Name: adm_user; Type: TABLE DATA; Schema: square; Owner: -
--

COPY square.adm_user (id, name, caption, hash, person_id) FROM stdin;
\.
COPY square.adm_user (id, name, caption, hash, person_id) FROM '$$PATH$$/3199.dat';

--
-- Data for Name: adm_user_group; Type: TABLE DATA; Schema: square; Owner: -
--

COPY square.adm_user_group (id, user_id, group_id) FROM stdin;
\.
COPY square.adm_user_group (id, user_id, group_id) FROM '$$PATH$$/3203.dat';

--
-- Data for Name: krn_menu_group; Type: TABLE DATA; Schema: square; Owner: -
--

COPY square.krn_menu_group (id, title, icon) FROM stdin;
\.
COPY square.krn_menu_group (id, title, icon) FROM '$$PATH$$/3211.dat';

--
-- Data for Name: krn_menu_item; Type: TABLE DATA; Schema: square; Owner: -
--

COPY square.krn_menu_item (id, group_id, title, url, icon) FROM stdin;
\.
COPY square.krn_menu_item (id, group_id, title, url, icon) FROM '$$PATH$$/3209.dat';

--
-- Data for Name: sqr_role; Type: TABLE DATA; Schema: square; Owner: -
--

COPY square.sqr_role (id, name, caption, description, group_id) FROM stdin;
\.
COPY square.sqr_role (id, name, caption, description, group_id) FROM '$$PATH$$/3218.dat';

--
-- Data for Name: sqr_square; Type: TABLE DATA; Schema: square; Owner: -
--

COPY square.sqr_square (id, name, caption, description) FROM stdin;
\.
COPY square.sqr_square (id, name, caption, description) FROM '$$PATH$$/3216.dat';

--
-- Data for Name: sqr_square_team; Type: TABLE DATA; Schema: square; Owner: -
--

COPY square.sqr_square_team (id, square_id, name, caption, description) FROM stdin;
\.
COPY square.sqr_square_team (id, square_id, name, caption, description) FROM '$$PATH$$/3221.dat';

--
-- Data for Name: sqr_square_timer; Type: TABLE DATA; Schema: square; Owner: -
--

COPY square.sqr_square_timer (id, square_id, team_id, caption, count, begin_time, pause_time, continue_time, stop_time, state) FROM stdin;
\.
COPY square.sqr_square_timer (id, square_id, team_id, caption, count, begin_time, pause_time, continue_time, stop_time, state) FROM '$$PATH$$/3223.dat';

--
-- Data for Name: sqr_square_timer_detail; Type: TABLE DATA; Schema: square; Owner: -
--

COPY square.sqr_square_timer_detail (id, timer_id, state, "time", count, description) FROM stdin;
\.
COPY square.sqr_square_timer_detail (id, timer_id, state, "time", count, description) FROM '$$PATH$$/3226.dat';

--
-- Data for Name: sqr_square_user; Type: TABLE DATA; Schema: square; Owner: -
--

COPY square.sqr_square_user (id, square_id, user_id, role_id, team_id) FROM stdin;
\.
COPY square.sqr_square_user (id, square_id, user_id, role_id, team_id) FROM '$$PATH$$/3220.dat';

--
-- Name: seq_adm_group; Type: SEQUENCE SET; Schema: square; Owner: -
--

SELECT pg_catalog.setval('square.seq_adm_group', 11, true);


--
-- Name: seq_adm_group_role; Type: SEQUENCE SET; Schema: square; Owner: -
--

SELECT pg_catalog.setval('square.seq_adm_group_role', 15, true);


--
-- Name: seq_adm_role; Type: SEQUENCE SET; Schema: square; Owner: -
--

SELECT pg_catalog.setval('square.seq_adm_role', 9, true);


--
-- Name: seq_adm_role_menu_item; Type: SEQUENCE SET; Schema: square; Owner: -
--

SELECT pg_catalog.setval('square.seq_adm_role_menu_item', 22, true);


--
-- Name: seq_adm_user; Type: SEQUENCE SET; Schema: square; Owner: -
--

SELECT pg_catalog.setval('square.seq_adm_user', 5, true);


--
-- Name: seq_adm_user_group; Type: SEQUENCE SET; Schema: square; Owner: -
--

SELECT pg_catalog.setval('square.seq_adm_user_group', 23, true);


--
-- Name: seq_krn_menu_group; Type: SEQUENCE SET; Schema: square; Owner: -
--

SELECT pg_catalog.setval('square.seq_krn_menu_group', 4, true);


--
-- Name: seq_krn_menu_item; Type: SEQUENCE SET; Schema: square; Owner: -
--

SELECT pg_catalog.setval('square.seq_krn_menu_item', 6, true);


--
-- Name: seq_sqr_role; Type: SEQUENCE SET; Schema: square; Owner: -
--

SELECT pg_catalog.setval('square.seq_sqr_role', 8, true);


--
-- Name: seq_sqr_square; Type: SEQUENCE SET; Schema: square; Owner: -
--

SELECT pg_catalog.setval('square.seq_sqr_square', 3, true);


--
-- Name: seq_sqr_square_role; Type: SEQUENCE SET; Schema: square; Owner: -
--

SELECT pg_catalog.setval('square.seq_sqr_square_role', 25, true);


--
-- Name: seq_sqr_square_team; Type: SEQUENCE SET; Schema: square; Owner: -
--

SELECT pg_catalog.setval('square.seq_sqr_square_team', 3, true);


--
-- Name: seq_sqr_square_timer; Type: SEQUENCE SET; Schema: square; Owner: -
--

SELECT pg_catalog.setval('square.seq_sqr_square_timer', 96, true);


--
-- Name: seq_sqr_square_timer_detail; Type: SEQUENCE SET; Schema: square; Owner: -
--

SELECT pg_catalog.setval('square.seq_sqr_square_timer_detail', 247, true);


--
-- Name: udx_adm_group_in_user_user_id; Type: INDEX; Schema: square; Owner: -
--

CREATE UNIQUE INDEX udx_adm_group_in_user_user_id ON square.adm_user_group USING btree (user_id, group_id);


--
-- Name: udx_adm_role_in_group_group_role_id; Type: INDEX; Schema: square; Owner: -
--

CREATE UNIQUE INDEX udx_adm_role_in_group_group_role_id ON square.adm_group_role USING btree (group_id, role_id);


--
-- Name: udx_adm_role_menu_item_role_id_menu_item_id; Type: INDEX; Schema: square; Owner: -
--

CREATE UNIQUE INDEX udx_adm_role_menu_item_role_id_menu_item_id ON square.adm_role_menu_item USING btree (role_id, menu_item_id);


--
-- Name: udx_krn_menu_item_group_id_title; Type: INDEX; Schema: square; Owner: -
--

CREATE UNIQUE INDEX udx_krn_menu_item_group_id_title ON square.krn_menu_item USING btree (group_id, title);


--
-- Name: udx_sqr_square_team_square_id_name_caption; Type: INDEX; Schema: square; Owner: -
--

CREATE UNIQUE INDEX udx_sqr_square_team_square_id_name_caption ON square.sqr_square_team USING btree (square_id, caption, name);


--
-- Name: udx_sqr_square_timer_square_id_team_id; Type: INDEX; Schema: square; Owner: -
--

CREATE UNIQUE INDEX udx_sqr_square_timer_square_id_team_id ON square.sqr_square_timer USING btree (square_id, team_id);


--
-- Name: udx_sqr_square_user_square_id_user_id_role_id; Type: INDEX; Schema: square; Owner: -
--

CREATE UNIQUE INDEX udx_sqr_square_user_square_id_user_id_role_id ON square.sqr_square_user USING btree (square_id, user_id, role_id);


--
-- Name: adm_group pk_adm_group; Type: CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.adm_group
    ADD CONSTRAINT pk_adm_group PRIMARY KEY (id);


--
-- Name: adm_user_group pk_adm_group_in_user; Type: CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.adm_user_group
    ADD CONSTRAINT pk_adm_group_in_user PRIMARY KEY (id);


--
-- Name: adm_role pk_adm_role; Type: CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.adm_role
    ADD CONSTRAINT pk_adm_role PRIMARY KEY (id);


--
-- Name: adm_group_role pk_adm_role_in_group; Type: CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.adm_group_role
    ADD CONSTRAINT pk_adm_role_in_group PRIMARY KEY (id);


--
-- Name: adm_role_menu_item pk_adm_role_menu_item; Type: CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.adm_role_menu_item
    ADD CONSTRAINT pk_adm_role_menu_item PRIMARY KEY (id);


--
-- Name: adm_user pk_adm_user; Type: CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.adm_user
    ADD CONSTRAINT pk_adm_user PRIMARY KEY (id);


--
-- Name: krn_menu_group pk_krn_manu_group; Type: CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.krn_menu_group
    ADD CONSTRAINT pk_krn_manu_group PRIMARY KEY (id);


--
-- Name: krn_menu_item pk_krn_menu_item; Type: CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.krn_menu_item
    ADD CONSTRAINT pk_krn_menu_item PRIMARY KEY (id);


--
-- Name: sqr_role pk_sqr_role; Type: CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.sqr_role
    ADD CONSTRAINT pk_sqr_role PRIMARY KEY (id);


--
-- Name: sqr_square pk_sqr_square; Type: CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.sqr_square
    ADD CONSTRAINT pk_sqr_square PRIMARY KEY (id);


--
-- Name: sqr_square_team pk_sqr_square_team; Type: CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.sqr_square_team
    ADD CONSTRAINT pk_sqr_square_team PRIMARY KEY (id);


--
-- Name: sqr_square_timer pk_sqr_square_timer; Type: CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.sqr_square_timer
    ADD CONSTRAINT pk_sqr_square_timer PRIMARY KEY (id);


--
-- Name: sqr_square_timer_detail pk_sqr_square_timer_detail; Type: CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.sqr_square_timer_detail
    ADD CONSTRAINT pk_sqr_square_timer_detail PRIMARY KEY (id);


--
-- Name: sqr_square_user pk_sqr_square_user; Type: CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.sqr_square_user
    ADD CONSTRAINT pk_sqr_square_user PRIMARY KEY (id);


--
-- Name: idx_adm_user_person_id; Type: INDEX; Schema: square; Owner: -
--

CREATE INDEX idx_adm_user_person_id ON square.adm_user USING btree (person_id);


--
-- Name: idx_krn_menu_item_group_id; Type: INDEX; Schema: square; Owner: -
--

CREATE INDEX idx_krn_menu_item_group_id ON square.krn_menu_item USING btree (group_id);


--
-- Name: idx_krn_menu_item_title; Type: INDEX; Schema: square; Owner: -
--

CREATE INDEX idx_krn_menu_item_title ON square.krn_menu_item USING btree (title);


--
-- Name: idx_sqr_role_caption; Type: INDEX; Schema: square; Owner: -
--

CREATE INDEX idx_sqr_role_caption ON square.sqr_role USING btree (caption);


--
-- Name: idx_sqr_role_group_id; Type: INDEX; Schema: square; Owner: -
--

CREATE INDEX idx_sqr_role_group_id ON square.sqr_role USING btree (group_id);


--
-- Name: idx_sqr_square_caption; Type: INDEX; Schema: square; Owner: -
--

CREATE INDEX idx_sqr_square_caption ON square.sqr_square USING btree (caption);


--
-- Name: idx_sqr_square_team_square_id; Type: INDEX; Schema: square; Owner: -
--

CREATE INDEX idx_sqr_square_team_square_id ON square.sqr_square_team USING btree (square_id);


--
-- Name: idx_sqr_square_timer_detail_timer_id; Type: INDEX; Schema: square; Owner: -
--

CREATE INDEX idx_sqr_square_timer_detail_timer_id ON square.sqr_square_timer_detail USING btree (timer_id);


--
-- Name: idx_sqr_square_user_team_id; Type: INDEX; Schema: square; Owner: -
--

CREATE INDEX idx_sqr_square_user_team_id ON square.sqr_square_user USING btree (team_id);


--
-- Name: udx_adm_group_name; Type: INDEX; Schema: square; Owner: -
--

CREATE UNIQUE INDEX udx_adm_group_name ON square.adm_group USING btree (name);


--
-- Name: udx_adm_role_name; Type: INDEX; Schema: square; Owner: -
--

CREATE UNIQUE INDEX udx_adm_role_name ON square.adm_role USING btree (name);


--
-- Name: udx_adm_user_name; Type: INDEX; Schema: square; Owner: -
--

CREATE UNIQUE INDEX udx_adm_user_name ON square.adm_user USING btree (name);


--
-- Name: udx_krn_manu_group_title; Type: INDEX; Schema: square; Owner: -
--

CREATE UNIQUE INDEX udx_krn_manu_group_title ON square.krn_menu_group USING btree (title);


--
-- Name: udx_sqr_role_name; Type: INDEX; Schema: square; Owner: -
--

CREATE UNIQUE INDEX udx_sqr_role_name ON square.sqr_role USING btree (name);


--
-- Name: udx_sqr_square_name; Type: INDEX; Schema: square; Owner: -
--

CREATE UNIQUE INDEX udx_sqr_square_name ON square.sqr_square USING btree (name);


--
-- Name: adm_user_group fk_adm_group_in_user_group_id; Type: FK CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.adm_user_group
    ADD CONSTRAINT fk_adm_group_in_user_group_id FOREIGN KEY (group_id) REFERENCES square.adm_group(id) ON DELETE CASCADE;


--
-- Name: adm_user_group fk_adm_group_in_user_user_id; Type: FK CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.adm_user_group
    ADD CONSTRAINT fk_adm_group_in_user_user_id FOREIGN KEY (user_id) REFERENCES square.adm_user(id) ON DELETE CASCADE;


--
-- Name: adm_group_role fk_adm_role_in_group_group; Type: FK CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.adm_group_role
    ADD CONSTRAINT fk_adm_role_in_group_group FOREIGN KEY (group_id) REFERENCES square.adm_group(id) ON DELETE CASCADE;


--
-- Name: adm_group_role fk_adm_role_in_group_role; Type: FK CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.adm_group_role
    ADD CONSTRAINT fk_adm_role_in_group_role FOREIGN KEY (role_id) REFERENCES square.adm_role(id) ON DELETE CASCADE;


--
-- Name: adm_role_menu_item fk_adm_role_menu_item_menu_item_id; Type: FK CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.adm_role_menu_item
    ADD CONSTRAINT fk_adm_role_menu_item_menu_item_id FOREIGN KEY (menu_item_id) REFERENCES square.krn_menu_item(id) ON DELETE CASCADE;


--
-- Name: adm_role_menu_item fk_adm_role_menu_item_role_id; Type: FK CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.adm_role_menu_item
    ADD CONSTRAINT fk_adm_role_menu_item_role_id FOREIGN KEY (role_id) REFERENCES square.adm_role(id) ON DELETE CASCADE;


--
-- Name: krn_menu_item fk_krn_menu_item_group_id; Type: FK CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.krn_menu_item
    ADD CONSTRAINT fk_krn_menu_item_group_id FOREIGN KEY (group_id) REFERENCES square.krn_menu_group(id) ON DELETE CASCADE;


--
-- Name: sqr_role fk_sqr_role_adm_group_id; Type: FK CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.sqr_role
    ADD CONSTRAINT fk_sqr_role_adm_group_id FOREIGN KEY (group_id) REFERENCES square.adm_group(id);


--
-- Name: sqr_square_team fk_sqr_square_team_square_id; Type: FK CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.sqr_square_team
    ADD CONSTRAINT fk_sqr_square_team_square_id FOREIGN KEY (square_id) REFERENCES square.sqr_square(id) ON DELETE CASCADE;


--
-- Name: sqr_square_timer_detail fk_sqr_square_timer_detail_timer_id; Type: FK CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.sqr_square_timer_detail
    ADD CONSTRAINT fk_sqr_square_timer_detail_timer_id FOREIGN KEY (timer_id) REFERENCES square.sqr_square_timer(id) ON DELETE CASCADE;


--
-- Name: sqr_square_timer fk_sqr_square_timer_square_id; Type: FK CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.sqr_square_timer
    ADD CONSTRAINT fk_sqr_square_timer_square_id FOREIGN KEY (square_id) REFERENCES square.sqr_square(id) ON DELETE CASCADE;


--
-- Name: sqr_square_timer fk_sqr_square_timer_team_id; Type: FK CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.sqr_square_timer
    ADD CONSTRAINT fk_sqr_square_timer_team_id FOREIGN KEY (team_id) REFERENCES square.sqr_square_team(id) ON DELETE CASCADE;


--
-- Name: sqr_square_user fk_sqr_square_user_role_id; Type: FK CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.sqr_square_user
    ADD CONSTRAINT fk_sqr_square_user_role_id FOREIGN KEY (role_id) REFERENCES square.sqr_role(id) ON DELETE CASCADE;


--
-- Name: sqr_square_user fk_sqr_square_user_square_id; Type: FK CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.sqr_square_user
    ADD CONSTRAINT fk_sqr_square_user_square_id FOREIGN KEY (square_id) REFERENCES square.sqr_square(id) ON DELETE CASCADE;


--
-- Name: sqr_square_user fk_sqr_square_user_team_id; Type: FK CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.sqr_square_user
    ADD CONSTRAINT fk_sqr_square_user_team_id FOREIGN KEY (team_id) REFERENCES square.sqr_square_team(id) ON DELETE CASCADE;


--
-- Name: sqr_square_user fk_sqr_square_user_user_id; Type: FK CONSTRAINT; Schema: square; Owner: -
--

ALTER TABLE ONLY square.sqr_square_user
    ADD CONSTRAINT fk_sqr_square_user_user_id FOREIGN KEY (user_id) REFERENCES square.adm_user(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

